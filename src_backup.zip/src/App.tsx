import { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import StorySection from './components/StorySection';
import OwnersSection from './components/OwnersSection';
import ServicesSection from './components/ServicesSection';
import TestimonialsSection from './components/TestimonialsSection';
import FaqSection from './components/FaqSection';
import FooterSection from './components/FooterSection';
import ContactModal from './components/ContactModal';

export default function App() {
  const [activeTab, setActiveTab] = useState('Event Plans');
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const navbar = document.getElementById('main-navbar');
      const navOffset = navbar ? navbar.offsetHeight + 35 : 85;
      const elementTop = el.getBoundingClientRect().top + window.scrollY;
      window.scrollTo({
        top: Math.max(0, elementTop - navOffset),
        behavior: 'smooth'
      });
    }
  };

  const handleSelectNavTab = (tab: string) => {
    setActiveTab(tab);
    if (tab === 'Event Plans' || tab === 'All Events') scrollToSection('tpbEventServicesSection');
    if (tab === 'Travel Plans' || tab === 'Tour & Travels') scrollToSection('tpbTravelServicesSection');
    if (tab === 'Reviews') scrollToSection('testimonials-section');
  };

  return (
    <div className="min-vh-100 bg-white text-dark d-flex flex-column position-relative">
      
      {/* Toast Notification with Gold Accent */}
      {toastMessage && (
        <div 
          className="position-fixed bottom-0 end-0 m-4 p-3 rounded-pill text-white small shadow-lg d-flex align-items-center gap-2 animate-fade-in"
          style={{
            zIndex: 1080,
            backgroundColor: 'var(--brand-burgundy-dark)',
            border: '1px solid rgba(197, 155, 63, 0.4)'
          }}
        >
          <i className="bi bi-stars" style={{ color: 'var(--brand-gold-light)' }}></i>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Floating Sticky Glassmorphic Navbar */}
      <Navbar
        activeTab={activeTab}
        onSelectTab={handleSelectNavTab}
        onContactNow={() => setIsContactOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-grow-1 w-100">
        
        {/* 2. Full-height Hero Section */}
        <Hero 
          onCheckNow={() => scrollToSection('tpbEventServicesSection')}
          onExploreExperience={() => scrollToSection('tpbEventServicesSection')}
        />

        {/* Main Content Layer (Slides OVER Fixed Hero like background-attachment: fixed) */}
        <div id="mainContentLayer" className="main-content-layer">
          {/* 3. Our Story Section */}
          <StorySection 
            onLearnMore={() => scrollToSection('tpbEventServicesSection')}
          />

          {/* 3.5 Meet The Owners (Interactive 3D Lanyard ID Cards) */}
          <OwnersSection />

          {/* 3.8 The Planner Broz Services (Event & Travel with 3D Depth Carousels) */}
          <ServicesSection />

          {/* 4. Client Testimonials */}
          <TestimonialsSection />

          {/* 5. FAQs Section (Accordion + Poolside Photo) */}
          <FaqSection />

          {/* 6. Footer Section (Bottom CTA, Big Watermark, Contact & Socials) */}
          <FooterSection 
            onPlanYourStay={() => scrollToSection('hero-section')}
            onSocialClick={(platform) => showToast(`Opening ${platform}`)}
            onLegalClick={(doc) => showToast(`Viewing ${doc}`)}
          />
        </div>
      </main>

      {/* Modals */}
      <ContactModal 
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
        onSubmitSuccess={(msg) => showToast(msg)}
      />

    </div>
  );
}

