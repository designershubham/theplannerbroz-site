/**
 * =========================================================================================
 * THE PLANNER BROZ — REACT SERVICES DATA CONFIGURATION
 * =========================================================================================
 * 
 * AAP YAHAN SE ASANI SE SAB KUCH CHANGE KAR SAKTE HAIN:
 * 1. Event Images & Videos
 * 2. Travel Images & Videos
 * 3. Headings, Subheadings & Descriptions
 * 4. Category Names & Icons
 * 5. Button Text & Links
 * 6. Carousel Auto-slide Speed
 * =========================================================================================
 */

export interface ServiceCategory {
  id: string;
  name: string;
  icon: string;
}

export interface GalleryPhoto {
  src: string;
  title: string;
  desc?: string;
}

export interface MediaItem {
  type: 'image' | 'video';
  title: string;
  src: string;
  poster?: string;
  alt?: string;
  subtitle?: string;
  gallery?: GalleryPhoto[];
}

export interface ServiceSectionConfig {
  badgeText: string;
  badgeIcon: string;
  headingMain: string;
  headingSub: string;
  headingHighlight: string;
  description: string;
  ctaText: string;
  ctaLink: string;
  heroBackgroundImage: string;
  categories: ServiceCategory[];
  viewAllText: string;
  viewAllLink: string;
  autoSlideSpeed: number;
  photos: MediaItem[];
  videos: MediaItem[];
}

export const EVENT_SERVICES_CONFIG: ServiceSectionConfig = {
  badgeText: "OUR EVENT SERVICES",
  badgeIcon: "✦",
  headingMain: "Event Planning",
  headingSub: "That Brings Your",
  headingHighlight: "Ideas to Life",
  description: "From intimate gatherings to large-scale celebrations, we design and manage events that create lasting impressions.",
  ctaText: "Explore Event Services",
  ctaLink: "#contactModal",
  heroBackgroundImage: "assets/event-hero-bg.jpg",
  categories: [
    { id: "corporate", name: "Corporate Events", icon: "bi-building" },
    { id: "brand-activations", name: "Brand Activations", icon: "bi-megaphone" },
    { id: "exhibitions", name: "Exhibitions & Launches", icon: "bi-people" },
    { id: "birthdays", name: "Birthdays & Private Parties", icon: "bi-cake2" },
    { id: "college-events", name: "College & School Events", icon: "bi-mortarboard" },
    { id: "pre-wedding", name: "Pre-Wedding Shoots", icon: "bi-camera" }
  ],
  viewAllText: "View All Events",
  viewAllLink: "#tpbEventServicesSection",
  autoSlideSpeed: 2400,
  photos: [
    {
      type: "image",
      title: "Wedding Decorations",
      src: "assets/events/wedding.jpg",
      alt: "Luxury Indian Wedding Mandap and Floral Decor",
      subtitle: "Grand Royal Indian Mandap, Floral Elegance & Bespoke Stage Architecture",
      gallery: [
        {
          src: "assets/events/wedding.jpg",
          title: "Royal Mandap & Floral Decor",
          desc: "Handcrafted floral arches with heritage brass accents, fresh tuberose and velvet seating"
        },
        {
          src: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80",
          title: "Luxury Floral Reception Entrance",
          desc: "Grand fairy-lit tunnel with cascading orchids, wisteria blooms and crystal chandeliers"
        },
        {
          src: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80",
          title: "Bespoke Royal Banquet Tablescape",
          desc: "Gold-trimmed bone china, crystal stemware, taper candles and aromatic rose centerpieces"
        },
        {
          src: "https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=80",
          title: "Traditional Haldi & Mehendi Setup",
          desc: "Vibrant marigold yellow theme with cozy low lounge seating and floating flower urli bowls"
        },
        {
          src: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?auto=format&fit=crop&w=1200&q=80",
          title: "Romantic Starlight Reception",
          desc: "Enchanting night lighting under open-air vintage tree canopies with warm festoon glows"
        },
        {
          src: "https://images.unsplash.com/photo-1545232979-8bf68ee9b1af?auto=format&fit=crop&w=1200&q=80",
          title: "Bridal Walkway & Aisle Design",
          desc: "Candlelit glass aisle adorned with velvet rose petals leading toward the regal stage"
        }
      ]
    },
    {
      type: "image",
      title: "Corporate Annual Meet",
      src: "assets/events/corporate.jpg",
      alt: "Night Palace Lawn Corporate Annual Gala",
      subtitle: "Keynote Stages, Executive Galas & Prestigious Corporate Summits",
      gallery: [
        {
          src: "assets/events/corporate.jpg",
          title: "Night Palace Lawn Corporate Gala",
          desc: "Grand illuminated heritage lawn setup with premium banqueting and keynote stage"
        },
        {
          src: "https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=80",
          title: "High-Tech Keynote Auditorium Stage",
          desc: "Seamless curved LED backdrop screens with dynamic architectural stage lighting"
        },
        {
          src: "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?auto=format&fit=crop&w=1200&q=80",
          title: "Global Leadership Presentation",
          desc: "State-of-the-art acoustic sound engineering and executive speaker lectern"
        },
        {
          src: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=1200&q=80",
          title: "Annual Convention & Delegate Hall",
          desc: "Ergonomic executive conference seating for 500+ guests with interactive voting pads"
        },
        {
          src: "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?auto=format&fit=crop&w=1200&q=80",
          title: "Executive Awards Night & Dinner",
          desc: "Black-tie awards ceremony with custom gold trophies, banquet dining and live entertainment"
        },
        {
          src: "https://images.unsplash.com/photo-1528605248644-14dd04022da1?auto=format&fit=crop&w=1200&q=80",
          title: "VIP Networking & Cocktail Lounge",
          desc: "Luxury cocktail lounge for C-suite networking, bespoke hors d'oeuvres and conversations"
        }
      ]
    },
    {
      type: "image",
      title: "Product Launch Event",
      src: "assets/events/product-launch.jpg",
      alt: "Grand Tech Summit Product Launch Keynote Stage",
      subtitle: "Futuristic Reveals, Dynamic Laser Stages & High-Impact Media Experiences",
      gallery: [
        {
          src: "assets/events/product-launch.jpg",
          title: "Grand Tech Summit Keynote Stage",
          desc: "Epic wide-angle stage with panoramic LED projections and dramatic countdown reveal"
        },
        {
          src: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=1200&q=80",
          title: "Cinematic Laser & Light Show",
          desc: "Synchronized laser beams and pyrotechnic cold sparks for maximum reveal impact"
        },
        {
          src: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=1200&q=80",
          title: "Live Audience Experience",
          desc: "Electrifying crowd atmosphere with immersive soundscapes and experiential zones"
        },
        {
          src: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1200&q=80",
          title: "Neon After-Party & Launch Lounge",
          desc: "Celebratory after-party with branded cocktail bars and energetic DJ beats"
        },
        {
          src: "https://images.unsplash.com/photo-1523580494863-6f3031224c94?auto=format&fit=crop&w=1200&q=80",
          title: "Interactive Experience Kiosks",
          desc: "Hands-on product touchpoints and demo zones for influencers and press media"
        },
        {
          src: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=1200&q=80",
          title: "Master Audio & Visual Console",
          desc: "Broadcast-grade live streaming and AV production control center"
        }
      ]
    },
    {
      type: "image",
      title: "Birthday Celebration",
      src: "assets/events/birthday.jpg",
      alt: "Magical Outdoor Floral Birthday Celebration Party",
      subtitle: "Bespoke Themed Decor, Fairy Light Canopies & Unforgettable Celebrations",
      gallery: [
        {
          src: "assets/events/birthday.jpg",
          title: "Magical Outdoor Birthday Setup",
          desc: "Whimsical garden setting with fairy-lit dinner table and personalized floral decor"
        },
        {
          src: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=1200&q=80",
          title: "Vibrant Balloon Arch Installation",
          desc: "Custom pastel & chrome balloon garland arch with customized neon signage"
        },
        {
          src: "https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?auto=format&fit=crop&w=1200&q=80",
          title: "Customized Designer Cake Stage",
          desc: "Multi-tier gourmet birthday cake display surrounded by floral pedestals"
        },
        {
          src: "https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=1200&q=80",
          title: "Golden Confetti Party Atmosphere",
          desc: "Gleaming golden party elements, customized party favors and sparklers"
        },
        {
          src: "https://images.unsplash.com/photo-1527529482837-4698179dc6ce?auto=format&fit=crop&w=1200&q=80",
          title: "Private Celebration Moments",
          desc: "Intimate family and friends gathering with celebratory toasts and joy"
        },
        {
          src: "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?auto=format&fit=crop&w=1200&q=80",
          title: "Night Garden Fairy Lights Party",
          desc: "Illuminated nighttime garden party with warm lanterns and acoustic live music"
        }
      ]
    },
    {
      type: "image",
      title: "Private Party Setup",
      src: "assets/events/private-party.jpg",
      alt: "Luxury VIP Outdoor Cabana Lounge Setup",
      subtitle: "VIP Cabana Lounges, Ambient Poolside Lighting & Crafted Cocktail Bars",
      gallery: [
        {
          src: "assets/events/private-party.jpg",
          title: "Luxury VIP Cabana Lounge",
          desc: "Sheer draped cabanas with plush velvet seating, oriental rugs and ambient lighting"
        },
        {
          src: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80",
          title: "Fine Dining Private Banquet",
          desc: "Intimate private dining room with bespoke menu curation and sommelier service"
        },
        {
          src: "https://images.unsplash.com/photo-1574096079513-d8259312b785?auto=format&fit=crop&w=1200&q=80",
          title: "Illuminated Poolside Sundowner",
          desc: "Floating pool candles, shoreline loungers and twilight cocktail service"
        },
        {
          src: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=1200&q=80",
          title: "Artisanal Cocktail & Wine Bar",
          desc: "Handcrafted cocktail station staffed by master mixologists with signature infusions"
        },
        {
          src: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?auto=format&fit=crop&w=1200&q=80",
          title: "Late Night Starlight Soiree",
          desc: "Sensational mood lighting, private bonfire pit and cozy outdoor seating"
        },
        {
          src: "https://images.unsplash.com/photo-1541532713592-79a0317b6b77?auto=format&fit=crop&w=1200&q=80",
          title: "Bespoke VIP Lounge Seating",
          desc: "Curated furniture vignettes with brass cocktail tables and fragrant orchid accents"
        }
      ]
    }
  ],
  videos: [
    {
      type: "video",
      title: "Royal Wedding Showcase",
      poster: "assets/events/wedding.jpg",
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      alt: "Royal Wedding Highlights Video"
    },
    {
      type: "video",
      title: "Product Launch Aftermovie",
      poster: "assets/events/product-launch.jpg",
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
      alt: "Tech Summit Keynote Video"
    },
    {
      type: "video",
      title: "Corporate Gala Highlights",
      poster: "assets/events/corporate.jpg",
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
      alt: "Corporate Gala Night Video"
    },
    {
      type: "video",
      title: "Neon Birthday Celebration",
      poster: "assets/events/birthday.jpg",
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
      alt: "Magical Birthday Video"
    },
    {
      type: "video",
      title: "Exclusive Private Lounge",
      poster: "assets/events/private-party.jpg",
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
      alt: "Private VIP Lounge Party Video"
    }
  ]
};

export const TRAVEL_SERVICES_CONFIG: ServiceSectionConfig = {
  badgeText: "OUR TRAVEL SERVICES",
  badgeIcon: "✈",
  headingMain: "Travel Experiences",
  headingSub: "Beyond",
  headingHighlight: "Destinations",
  description: "From group trips to corporate offsites, we plan travel experiences that bring people closer to new places and better memories.",
  ctaText: "Explore Travel Services",
  ctaLink: "#contactModal",
  heroBackgroundImage: "assets/travel-hero-bg.jpg",
  categories: [
    { id: "group-trips", name: "Group Trips", icon: "bi-people-fill" },
    { id: "family-holidays", name: "Family Holidays", icon: "bi-house-heart" },
    { id: "offsites", name: "Offsites & Corporate Travel", icon: "bi-briefcase" },
    { id: "tours-experiences", name: "Tours & Travel Experiences", icon: "bi-geo-alt" },
    { id: "mice", name: "MICE", icon: "bi-building-check" },
    { id: "custom-itineraries", name: "Customized Itineraries", icon: "bi-bezier2" }
  ],
  viewAllText: "View All Trips",
  viewAllLink: "#tpbTravelServicesSection",
  autoSlideSpeed: 2400,
  photos: [
    {
      type: "image",
      title: "Manali Group Trip",
      src: "assets/travel/manali.jpg",
      alt: "Manali Himalayan River and Pine Forest Valley",
      subtitle: "Snow-Capped Peaks, Riverside Camping & High-Altitude Himalayan Adventures",
      gallery: [
        {
          src: "assets/travel/manali.jpg",
          title: "Himalayan River & Pine Valley",
          desc: "Rushing glacial Beas river framed by towering deodar pine forests and serene valley air"
        },
        {
          src: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?auto=format&fit=crop&w=1200&q=80",
          title: "Solang Valley Snow Peaks",
          desc: "Panoramic snowy ridges, paragliding launches and high-altitude mountain lookouts"
        },
        {
          src: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80",
          title: "Riverside Luxury Dome Stays",
          desc: "Geodesic glamping domes nestled along lush riverbanks with personal bonfire hearths"
        },
        {
          src: "https://images.unsplash.com/photo-1510312305653-8ed496efae75?auto=format&fit=crop&w=1200&q=80",
          title: "Starlit Himalayan Campfire",
          desc: "Evening stargazing, barbecue dinners and acoustic music under crystal-clear alpine skies"
        },
        {
          src: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=80",
          title: "Rohtang Pass Mountain Expedition",
          desc: "Thrilling high-altitude mountain pass drives with breathtaking glacier views"
        },
        {
          src: "https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?auto=format&fit=crop&w=1200&q=80",
          title: "Old Manali Wooden Cafe Trails",
          desc: "Charming cedar wood cafes, artisanal bakery trails and vibrant mountain culture"
        }
      ]
    },
    {
      type: "image",
      title: "Jaipur Corporate Offsite",
      src: "assets/travel/jaipur.jpg",
      alt: "Nahargarh Fort Sunset View with Colleagues in Jaipur",
      subtitle: "Royal Fort Sunsets, Desert Safari Camps & Heritage Palace Conclaves",
      gallery: [
        {
          src: "assets/travel/jaipur.jpg",
          title: "Nahargarh Fort Royal Sunset",
          desc: "Golden hour sunset over the Pink City panorama from the historic ramparts of Nahargarh"
        },
        {
          src: "https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1200&q=80",
          title: "Hawa Mahal Iconic Architecture",
          desc: "Intricately carved pink sandstone honeycomb facade in the heart of the royal heritage quarter"
        },
        {
          src: "https://images.unsplash.com/photo-1597040663342-45b6af3d91a5?auto=format&fit=crop&w=1200&q=80",
          title: "Amer Fort Royal Courtyards",
          desc: "Grand palatial gateways, Sheesh Mahal mirrored chambers and majestic courtyards"
        },
        {
          src: "https://images.unsplash.com/photo-1477587458883-47145ed94245?auto=format&fit=crop&w=1200&q=80",
          title: "Heritage Haveli Welcome & Folk Dance",
          desc: "Traditional Rajasthani welcome with Kalbelia dancers, dhol beats and royal rose water showers"
        },
        {
          src: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=1200&q=80",
          title: "Sam Dunes Luxury Desert Safari",
          desc: "Sunset camel treks, quad biking across undulating golden sand dunes and bonfire galas"
        },
        {
          src: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?auto=format&fit=crop&w=1200&q=80",
          title: "Maharaja Palace Conclave & Dining",
          desc: "Heritage palace conference setup followed by royal 21-course Rajasthani thali banquet"
        }
      ]
    },
    {
      type: "image",
      title: "Udaipur Family Holiday",
      src: "assets/travel/udaipur.jpg",
      alt: "Pichola Royal Boat Cruise facing Udaipur Lake Palace",
      subtitle: "Lake Pichola Sunset Cruises, Grand Haveli Stays & Regal Courtyard Dinners",
      gallery: [
        {
          src: "assets/travel/udaipur.jpg",
          title: "Lake Pichola Royal Boat Cruise",
          desc: "Private heritage boat cruise gliding past the glistening marble facades of Lake Palace"
        },
        {
          src: "https://images.unsplash.com/photo-1595815771614-ade9d652a65d?auto=format&fit=crop&w=1200&q=80",
          title: "City Palace Heritage Courtyard",
          desc: "Regal peacock mosaics, historic royal balconies and panoramic views of Lake Pichola"
        },
        {
          src: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=1200&q=80",
          title: "Grand Jharokha Architectural Arches",
          desc: "Iconic scalloped marble arches framing romantic sunset vistas over the Aravali hills"
        },
        {
          src: "https://images.unsplash.com/photo-1567157577867-05ccb1388e66?auto=format&fit=crop&w=1200&q=80",
          title: "Jag Mandir Island Sunset Banquet",
          desc: "Candlelit family dinner on the historic island palace with gentle lakeside breezes"
        },
        {
          src: "https://images.unsplash.com/photo-1585123388867-3bfe6dd4bdbf?auto=format&fit=crop&w=1200&q=80",
          title: "Sajjangarh Monsoon Palace Overlook",
          desc: "Panoramic clifftop palace vantage point overlooking the lakes and distant hills"
        },
        {
          src: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=1200&q=80",
          title: "Lakeside Heritage Haveli Stay",
          desc: "Authentic royal hospitality, heritage suites with antique brass decor and lakefront terraces"
        }
      ]
    },
    {
      type: "image",
      title: "Goa Beach Trip",
      src: "assets/travel/goa.jpg",
      alt: "Golden Sunset Beach with Palm Trees in Goa",
      subtitle: "Golden Coastline Sunsets, Catamaran Yacht Cruises & Cliffside Stays",
      gallery: [
        {
          src: "assets/travel/goa.jpg",
          title: "Golden Coastline Sunset & Palms",
          desc: "Warm Arabian Sea breezes, leaning coconut groves and idyllic golden sand shores"
        },
        {
          src: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80",
          title: "Turquoise Shoreline & Beach Day",
          desc: "Pristine sandy stretches for private sunbathing, beach volleyball and relaxation"
        },
        {
          src: "https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=80",
          title: "Portuguese Luxury Villa & Pool",
          desc: "Private heritage villa with infinity pool, lush tropical gardens and private chef"
        },
        {
          src: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=1200&q=80",
          title: "Private Catamaran Yacht Charter",
          desc: "Sunset sailing along the Mandovi river and sea caves with chilled beverages and music"
        },
        {
          src: "https://images.unsplash.com/photo-1519046904884-53103b34b206?auto=format&fit=crop&w=1200&q=80",
          title: "Beachside Sundowner Lounges",
          desc: "Bohemian beachfront cabanas with handcrafted tropical cocktails and live DJ sunset sets"
        },
        {
          src: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=1200&q=80",
          title: "Candlelit Coastal Seafood Dinner",
          desc: "Fresh catch of the day barbecued right on the beach accompanied by acoustic guitar tunes"
        }
      ]
    },
    {
      type: "image",
      title: "Kashmir Winter Trip",
      src: "assets/travel/kashmir.jpg",
      alt: "Friends Enjoying Snow in Gulmarg Kashmir",
      subtitle: "Gulmarg Powder Snow Slopes, Dal Lake Shikara Rides & Pine Wonderland",
      gallery: [
        {
          src: "assets/travel/kashmir.jpg",
          title: "Gulmarg Snow Wonderland",
          desc: "Crisp mountain powder, playful snowball moments and snow-laden pine trees in Gulmarg"
        },
        {
          src: "https://images.unsplash.com/photo-1566837945700-30057527ade0?auto=format&fit=crop&w=1200&q=80",
          title: "Dal Lake Shikara Morning Ride",
          desc: "Gliding through misty waters in a cushioned wooden Shikara with floating flower markets"
        },
        {
          src: "https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=1200&q=80",
          title: "Group Snow Adventure Moments",
          desc: "Cherished travel memories with friends exploring snowy mountain trails and viewpoints"
        },
        {
          src: "https://images.unsplash.com/photo-1548777123-e216912df7d8?auto=format&fit=crop&w=1200&q=80",
          title: "Pahalgam Deep Pine Forest Trek",
          desc: "Untouched pristine snowscapes in Betaab Valley and Aru framed by Himalayan ridges"
        },
        {
          src: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=1200&q=80",
          title: "High-Altitude Gondola Expedition",
          desc: "World's second-highest cable car ascending to 14,000 ft Apharwat Peak with ski slopes"
        },
        {
          src: "https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1200&q=80",
          title: "Traditional Cedar Wood Houseboat",
          desc: "Cozy walnut-wood carved houseboats on Nigeen Lake with steaming Kashmiri Kahwa"
        }
      ]
    }
  ],
  videos: [
    {
      type: "video",
      title: "Manali Valley Expedition",
      poster: "assets/travel/manali.jpg",
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
      alt: "Manali Scenic Journey Video"
    },
    {
      type: "video",
      title: "Jaipur Heritage Sunset",
      poster: "assets/travel/jaipur.jpg",
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
      alt: "Jaipur Royal Fort Exploration Video"
    },
    {
      type: "video",
      title: "Lake Pichola Sunset Cruise",
      poster: "assets/travel/udaipur.jpg",
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
      alt: "Udaipur Boat Cruise Experience Video"
    },
    {
      type: "video",
      title: "Goa Coastal Beachside",
      poster: "assets/travel/goa.jpg",
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackSeeTheWorld.mp4",
      alt: "Goa Sunset Beach Tour Video"
    },
    {
      type: "video",
      title: "Kashmir Snow Wonderland",
      poster: "assets/travel/kashmir.jpg",
      src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
      alt: "Gulmarg Kashmir Winter Snow Trip Video"
    }
  ]
};
