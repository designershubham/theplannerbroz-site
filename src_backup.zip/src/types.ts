

export interface TestimonialItem {
  id: string;
  headline: string;
  quote: string;
  author: string;
  role?: string;
  location?: string;
  rating: string | number;
  avatar?: string;
  avatarUrl?: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}
