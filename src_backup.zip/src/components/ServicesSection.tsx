import React from 'react';
import { EVENT_SERVICES_CONFIG, TRAVEL_SERVICES_CONFIG } from '../data/servicesData';
import ServiceHero from './ServiceHero';
import MediaCarousel from './MediaCarousel';

export const ServicesSection: React.FC = () => {
  return (
    <div id="tpbServicesRoot" className="tpb-services-master-container">
      {/* SVG ClipPath for Multi-Wave Organic Banner Bottom Curve */}
      <svg width="0" height="0" style={{ position: 'absolute', width: 0, height: 0, pointerEvents: 'none' }} aria-hidden="true">
        <defs>
          <clipPath id="tpbHeroCurvePath" clipPathUnits="objectBoundingBox">
            <path d="M 0,0.05 C 0,0.02 0.02,0 0.04,0 L 0.96,0 C 0.98,0 1,0.02 1,0.05 L 1,0.96 C 0.96,0.985 0.88,0.995 0.72,0.995 C 0.56,0.995 0.48,0.97 0.38,0.955 C 0.28,0.94 0.20,0.965 0.12,0.98 C 0.06,0.985 0.02,0.975 0,0.96 Z" />
          </clipPath>
        </defs>
      </svg>

      {/* =====================================================================
          1. EVENT SERVICES
          ===================================================================== */}
      <section id="tpbEventServicesSection" className="tpb-service-block">
        <div className="container-fluid">
          {/* Event Hero with Category Bar */}
          <ServiceHero config={EVENT_SERVICES_CONFIG} />

          {/* Event Media Carousel (Photos / Videos with 3D Depth) */}
          <MediaCarousel
            photos={EVENT_SERVICES_CONFIG.photos}
            videos={EVENT_SERVICES_CONFIG.videos}
            viewAllText={EVENT_SERVICES_CONFIG.viewAllText}
            viewAllLink={EVENT_SERVICES_CONFIG.viewAllLink}
            autoSlideSpeed={EVENT_SERVICES_CONFIG.autoSlideSpeed}
            reverseDirection={false}
          />
        </div>
      </section>

      {/* =====================================================================
          2. TRAVEL SERVICES (With Luxury Gap & Opposite Direction Carousel)
          ===================================================================== */}
      <section id="tpbTravelServicesSection" className="tpb-service-block">
        <div className="container-fluid">
          {/* Travel Hero with Category Bar */}
          <ServiceHero config={TRAVEL_SERVICES_CONFIG} />

          {/* Travel Media Carousel (Opposite auto-slide direction) */}
          <MediaCarousel
            photos={TRAVEL_SERVICES_CONFIG.photos}
            videos={TRAVEL_SERVICES_CONFIG.videos}
            viewAllText={TRAVEL_SERVICES_CONFIG.viewAllText}
            viewAllLink={TRAVEL_SERVICES_CONFIG.viewAllLink}
            autoSlideSpeed={TRAVEL_SERVICES_CONFIG.autoSlideSpeed}
            reverseDirection={true}
          />
        </div>
      </section>
    </div>
  );
};

export default ServicesSection;
