"use client";

import React, { useEffect, useRef, useState } from "react";
import qrcode from "../../lib/qrcode";

export interface IDCardLanyardProps {
  name?: string;
  role?: string;
  brand?: string;
  brandTagline?: string;
  pillars?: string[] | [string, string, string];
  department?: string;
  location?: string;
  email?: string;
  phone?: string;
  idNumber?: string;
  validThru?: string;
  site?: string;
  photoUrl?: string;
  githubUrl?: string;
  linkedinUrl?: string;
  instagramUrl?: string;
  whatsappUrl?: string;
  qrUrl?: string;
  anchorX?: string | number;
  anchorY?: number;
  zIndex?: number;
  containerMode?: "relative" | "fixed";
  showHint?: boolean;
  className?: string;
}

interface Point {
  x: number;
  y: number;
  oldx: number;
  oldy: number;
  pinned: boolean;
}

const CSS = `
.idcl-root{--idcl-accent:#C59B3F;--idcl-card:#FAF7F2;font-family:'Plus Jakarta Sans',system-ui,sans-serif;width:100%;height:100%}
.idcl-root *{box-sizing:border-box}
.idcl-stage{position:absolute;inset:0;z-index:var(--idcl-z,10);pointer-events:none;overflow:visible}
.idcl-stage.idcl-fixed{position:fixed}
.idcl-rope{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}
.idcl-rail{position:absolute;top:0;width:80px;height:8px;transform:translateX(-50%);background:linear-gradient(180deg,#3D111A,#22070D);border-radius:0 0 6px 6px;box-shadow:0 3px 8px rgba(34,7,13,.4);pointer-events:none}
.idcl-card{position:absolute;width:clamp(310px,32vw,350px);aspect-ratio:340/560;perspective:1400px;cursor:grab;touch-action:none;user-select:none;transform-origin:top center;pointer-events:auto}
.idcl-card:active{cursor:grabbing}
.idcl-flipper{position:relative;width:100%;height:100%;transform-style:preserve-3d}
.idcl-face{position:absolute;inset:0;border-radius:24px;padding:16px 18px 14px;display:flex;flex-direction:column;backface-visibility:hidden;border:1.5px solid rgba(197,155,63,.45);background:#FAF7F2;box-shadow:0 24px 48px -12px rgba(34,7,13,.22),0 8px 20px -6px rgba(197,155,63,.2),inset 0 1px 0 rgba(255,255,255,.95);overflow:hidden}
.idcl-face::after{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;background:radial-gradient(circle at var(--mx,50%) var(--my,50%),rgba(255,255,255,.65),transparent 45%);mix-blend-mode:overlay;opacity:0;transition:opacity .3s ease;z-index:5}
.idcl-card.idcl-hovering .idcl-face::after{opacity:1}
.idcl-bg-swoosh{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:0}
.idcl-face-content{position:relative;z-index:2;display:flex;flex-direction:column;height:100%}
.idcl-front{background:#FAF7F2;align-items:stretch;text-align:left}
.idcl-back{background:linear-gradient(165deg,#F5EDE2,#FAF7F2);transform:rotateY(180deg)}
.idcl-hole{width:44px;height:10px;background:#1A1A1A;border-radius:5px;margin:0 auto 10px;flex-shrink:0;opacity:.92}
.idcl-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px}
.idcl-brand{display:flex;align-items:flex-start;gap:6px}
.idcl-brand-star{width:15px;height:15px;flex-shrink:0;margin-top:1px}
.idcl-brand-text b{font-weight:800;font-size:13.5px;letter-spacing:.04em;color:#111827;line-height:1.1;display:block}
.idcl-brand-tagline{font-size:6.8px;letter-spacing:.14em;text-transform:uppercase;color:#78716C;font-weight:700;margin-top:2px;display:block}
.idcl-pillars{display:flex;flex-direction:column;align-items:flex-end;gap:1px}
.idcl-pillars span{font-size:7.5px;letter-spacing:.14em;text-transform:uppercase;color:#57534E;font-weight:700;line-height:1.3}
.idcl-pillars-line{width:24px;height:2px;background:#C59B3F;margin-top:3px}
.idcl-photo-container{position:relative;width:100%;height:185px;border-radius:18px;background:#F2EBE0;overflow:hidden;margin-bottom:12px;flex-shrink:0;border:1px solid rgba(197,155,63,.28);box-shadow:0 4px 16px rgba(0,0,0,.06)}
.idcl-photo-container img{width:100%;height:100%;object-fit:cover;object-position:center 20%;display:block}
.idcl-verified-badge{position:absolute;right:12px;bottom:8px;width:28px;height:28px;border-radius:50%;background:#C59B3F;display:flex;align-items:center;justify-content:center;color:#fff;box-shadow:0 3px 8px rgba(0,0,0,.18),0 0 0 2.5px #FFFFFF;z-index:3}
.idcl-identity{margin-bottom:12px;text-align:left}
.idcl-name{margin:0 0 2px;font-weight:800;font-size:21px;color:#111827;letter-spacing:-.015em;line-height:1.15}
.idcl-role{margin:0;font-size:10px;color:#B88628;font-weight:700;letter-spacing:.16em;text-transform:uppercase}
.idcl-info-section{display:flex;justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:8px}
.idcl-table{flex:1;display:flex;flex-direction:column;gap:2.5px;min-width:0}
.idcl-row{display:flex;align-items:center;padding:3.5px 0;border-bottom:1px solid #ECE4D8;font-size:8.5px;line-height:1.2}
.idcl-row-icon{width:16px;height:16px;border-radius:4px;background:#F0EAE1;margin-right:5px;color:#8C7E73;flex-shrink:0;display:flex;align-items:center;justify-content:center}
.idcl-row-label{width:66px;flex-shrink:0;font-size:7.5px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#78716C}
.idcl-row-sep{margin:0 3px 0 1px;color:#A8A29E;font-weight:600}
.idcl-row-val{font-size:8.5px;font-weight:700;color:#1C1917;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.idcl-qr-col{width:68px;flex-shrink:0;display:flex;flex-direction:column;align-items:center;text-align:center;padding-top:2px}
.idcl-qr-link{display:block;text-decoration:none;cursor:pointer;transition:transform .22s cubic-bezier(.34,1.56,.64,1)}
.idcl-qr-link:hover{transform:scale(1.05)}
.idcl-qr-frame{width:66px;height:66px;background:#FFFFFF;padding:4px;border-radius:8px;box-shadow:0 3px 12px rgba(197,155,63,.2),0 0 0 1px #E7DFD4;border:1px solid rgba(197,155,63,.4);display:flex;align-items:center;justify-content:center;transition:border-color .2s ease,box-shadow .2s ease}
.idcl-qr-link:hover .idcl-qr-frame{border-color:#C59B3F;box-shadow:0 5px 16px rgba(197,155,63,.35),0 0 0 1.5px #C59B3F}
.idcl-qr-frame svg{width:100%;height:100%;display:block;border-radius:4px}
.idcl-qr-caption{margin-top:4px;font-size:6.5px;letter-spacing:.12em;font-weight:700;text-transform:uppercase;color:#78716C;line-height:1.25}
.idcl-qr-line{width:22px;height:2px;background:#C59B3F;margin-top:3px;border-radius:1px}
.idcl-sig-section{display:flex;flex-direction:column;align-items:center;margin-top:4px;margin-bottom:8px}
.idcl-sig-script{font-family:'Caveat',cursive;font-size:24px;font-weight:600;color:#1C1917;line-height:1;margin-bottom:2px}
.idcl-sig-label{font-size:6.5px;letter-spacing:.18em;text-transform:uppercase;color:#78716C;border-top:1px solid #D6CCBE;padding-top:3px;width:130px;text-align:center;font-weight:600}
.idcl-card-footer{display:flex;align-items:center;justify-content:center;gap:10px;margin-top:auto;padding-top:8px}
.idcl-footer-line{width:28px;height:1.5px;background:#C59B3F}
.idcl-footer-text{font-size:8px;letter-spacing:.18em;text-transform:uppercase;font-weight:700;color:#57534E}
.idcl-footer-star{color:#C59B3F;font-size:8px}
.idcl-stripe{width:100%;height:32px;background:repeating-linear-gradient(45deg,#22070D,#22070D 6px,#3D111A 6px,#3D111A 12px);border-radius:4px;margin-bottom:14px}
.idcl-barcode{display:flex;align-items:flex-end;gap:2px;height:34px;width:100%;background:#fff;border-radius:4px;padding:0 6px;margin-bottom:8px;overflow:hidden}
.idcl-barcode span{width:2.5px;background:#22070D}
.idcl-idnum{margin:0 0 8px;font-family:'Plus Jakarta Sans',monospace;font-size:11px;font-weight:700;color:#22070D;letter-spacing:.04em;display:flex;justify-content:space-between}
.idcl-idnum em{font-style:normal;color:#C59B3F}
.idcl-backrow{display:flex;gap:12px;align-items:center;margin-bottom:12px;background:#FFFFFF;padding:10px 12px;border-radius:12px;border:1px solid #ECE4D8;box-shadow:0 2px 8px rgba(0,0,0,.04)}
.idcl-backrow .qr-back{width:76px;height:76px;flex-shrink:0;padding:4px;border-radius:8px;border:1.5px solid rgba(197,155,63,.45);box-shadow:0 4px 14px rgba(197,155,63,.22)}
.idcl-scan{font-size:9.5px;color:#685E58;line-height:1.45}
.idcl-scan b{color:#22070D;display:block;font-size:10.5px;margin-bottom:2px;letter-spacing:.04em}
.idcl-scan-url{color:#C59B3F;font-weight:700;font-size:9px;letter-spacing:.03em}
.idcl-scan-prompt{display:inline-block;margin-top:3px;font-size:8.5px;color:#8C7E73;font-weight:600}
.idcl-connect{display:flex;align-items:center;justify-content:space-between;margin-top:10px}
.idcl-connect span{font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:#78716C;font-weight:700}
.idcl-connect-icons{display:flex;gap:6px}
.idcl-connect-icons a{width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:1px solid #ECE4D8;color:#78716C;background:#FAF7F2;transition:all .15s ease}
.idcl-connect-icons a:hover{border-color:var(--idcl-accent);color:#fff;background:var(--idcl-accent);transform:translateY(-1px)}
.idcl-connect-icons svg{width:13px;height:13px}
.idcl-sig{margin-top:10px}
.idcl-sig .idcl-script{font-family:'Caveat',cursive;font-size:24px;color:#111827;line-height:1}
.idcl-sig small{display:block;font-size:8px;letter-spacing:.08em;text-transform:uppercase;color:#78716C;border-top:1px solid #ECE4D8;margin-top:3px;padding-top:3px;font-weight:600}
.idcl-hint{position:absolute;bottom:12px;left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:6px;background:rgba(34,7,13,.78);color:#FAF7F2;border:1px solid rgba(197,155,63,.4);padding:6px 14px;border-radius:999px;font-size:10.5px;letter-spacing:.04em;pointer-events:none;opacity:1;transition:opacity .4s ease;white-space:nowrap;z-index:20}
.idcl-hint.idcl-hint-hidden{opacity:0}
.idcl-hint svg{width:12px;height:12px;color:var(--idcl-accent);flex-shrink:0}
`;

const ICONS: Record<string, React.ReactNode> = {
  id: <svg viewBox="0 0 24 24" width={11} height={11} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><rect x={3} y={4} width={18} height={16} rx={2} /><circle cx={12} cy={10} r={3} /><line x1={7} y1={18} x2={17} y2={18} /></svg>,
  dept: <svg viewBox="0 0 24 24" width={11} height={11} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><rect x={2} y={7} width={20} height={14} rx={2} ry={2} /><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" /></svg>,
  loc: <svg viewBox="0 0 24 24" width={11} height={11} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx={12} cy={10} r={3} /></svg>,
  email: <svg viewBox="0 0 24 24" width={11} height={11} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" /><polyline points="22,6 12,13 2,6" /></svg>,
  phone: <svg viewBox="0 0 24 24" width={11} height={11} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" /></svg>,
  valid: <svg viewBox="0 0 24 24" width={11} height={11} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><rect x={3} y={4} width={18} height={18} rx={2} ry={2} /><line x1={16} y1={2} x2={16} y2={6} /><line x1={8} y1={2} x2={8} y2={6} /><line x1={3} y1={10} x2={21} y2={10} /></svg>,
};



function UniqueScannableQR({ url }: { url: string }) {
  try {
    const qr = qrcode(0, "M");
    qr.addData(url || "https://instagram.com");
    qr.make();
    const count = qr.getModuleCount();
    const margin = 2;
    const total = count + margin * 2;

    const isFinder = (r: number, c: number) => {
      if (r < 7 && c < 7) return true;
      if (r < 7 && c >= count - 7) return true;
      if (r >= count - 7 && c < 7) return true;
      return false;
    };

    const dots: React.ReactNode[] = [];
    for (let r = 0; r < count; r++) {
      for (let c = 0; c < count; c++) {
        if (isFinder(r, c)) continue;
        if (qr.isDark(r, c)) {
          dots.push(
            <rect
              key={`${r}-${c}`}
              x={c + margin}
              y={r + margin}
              width={0.9}
              height={0.9}
              rx={0.22}
              fill="#1C1917"
            />
          );
        }
      }
    }

    const renderEye = (x: number, y: number, key: string) => (
      <g key={key}>
        <rect x={x} y={y} width={7} height={7} rx={1.6} fill="#C59B3F" />
        <rect x={x + 1} y={y + 1} width={5} height={5} rx={1.1} fill="#FFFFFF" />
        <rect x={x + 2} y={y + 2} width={3} height={3} rx={0.8} fill="#22070D" />
      </g>
    );

    return (
      <svg viewBox={`0 0 ${total} ${total}`} width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" shapeRendering="geometricPrecision">
        <rect width={total} height={total} fill="#FFFFFF" rx={2} />
        {renderEye(margin, margin, "tl")}
        {renderEye(margin + count - 7, margin, "tr")}
        {renderEye(margin, margin + count - 7, "bl")}
        {dots}
      </svg>
    );
  } catch {
    return <div style={{ fontSize: "8px", color: "#C59B3F", textAlign: "center", padding: "8px" }}>✦ VIP ✦</div>;
  }
}

export function IDCardLanyard({
  name = "Aryan Sharma",
  role = "CO- FOUNDER & MANAGING DIRECTOR",
  brand = "THE PLANNER BROZ",
  brandTagline = "EVENTS ✦ EXPERIENCES ✦ TRAVEL ✦ BRAND ACTIVATIONS",
  pillars = ["VISION", "PLAN", "EXECUTE"],
  department = "Leadership",
  location = "New Delhi - Mumbai",
  email = "aryan@theplannerbroz.com",
  phone = "+91 98765 43210",
  idNumber = "TPB-001",
  validThru = "Lifetime",
  site = "theplannerbroz.com",
  photoUrl = "/assets/founder-aryan.jpg",
  githubUrl,
  linkedinUrl = "https://linkedin.com",
  instagramUrl = "https://instagram.com",
  whatsappUrl = "https://wa.me/919876543210",
  qrUrl,
  anchorX = "50%",
  anchorY = 8,
  zIndex = 10,
  containerMode = "relative",
  showHint = true,
  className = "",
}: IDCardLanyardProps) {
  const sceneRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const railRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const flipperRef = useRef<HTMLDivElement>(null);
  const [interacted, setInteracted] = useState(false);

  useEffect(() => {
    const fontId = "idcl-fonts";
    if (!document.getElementById(fontId)) {
      const link = document.createElement("link");
      link.id = fontId;
      link.rel = "stylesheet";
      link.href = "https://fonts.googleapis.com/css2?family=Caveat:wght@600;700&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap";
      document.head.appendChild(link);
    }
  }, []);

  useEffect(() => {
    const scene = sceneRef.current;
    const canvas = canvasRef.current;
    const rail = railRef.current;
    const card = cardRef.current;
    const flipper = flipperRef.current;
    if (!scene || !canvas || !rail || !card || !flipper) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const anchorYVal = anchorY ?? 8;
    const resolveAnchorX = () => {
      if (typeof anchorX === "number") return anchorX;
      if (typeof anchorX === "string") {
        const v = anchorX.trim();
        if (v.endsWith("%")) return scene.clientWidth * (parseFloat(v) / 100);
        if (v.endsWith("px")) return parseFloat(v);
      }
      return scene.clientWidth * 0.5;
    };
    const anchor = { x: resolveAnchorX(), y: anchorYVal };

    const resize = () => {
      const w = scene.clientWidth;
      const h = scene.clientHeight;
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
      }
      anchor.x = resolveAnchorX();
      rail.style.left = `${anchor.x}px`;
      rail.style.top = `${anchor.y - 3}px`;
    };
    resize();

    const NUM_POINTS = 13;
    const REST_LENGTH = 110;
    const SEG_LEN = REST_LENGTH / (NUM_POINTS - 1);
    const GRAVITY = 0.55;
    const FRICTION = 0.98;

    const pts: Point[] = Array.from({ length: NUM_POINTS }, (_, i) => ({
      x: anchor.x,
      y: anchor.y + i * SEG_LEN,
      oldx: anchor.x,
      oldy: anchor.y + i * SEG_LEN,
      pinned: i === 0,
    }));

    let dragging = false;
    let flipped = false;
    let downPos = { x: anchor.x, y: anchor.y };
    let ptr = { x: anchor.x, y: anchor.y + REST_LENGTH };
    let lastPtr = { x: ptr.x, y: ptr.y };
    let vel = { x: 0, y: 0 };
    let flipTarget = 0;
    let flipCurrent = 0;
    const tilt = { targetX: 0, targetY: 0, curX: 0, curY: 0 };
    let mouse = { x: -9999, y: -9999 };

    const getPos = (e: { clientX: number; clientY: number }) => {
      const r = scene.getBoundingClientRect();
      return { x: e.clientX - r.left, y: e.clientY - r.top };
    };

    const clamp = (p: { x: number; y: number }) => {
      p.x = Math.max(16, Math.min(canvas.width - 16, p.x));
      p.y = Math.max(anchor.y + 15, Math.min(canvas.height - 30, p.y));
    };

    const stepPhysics = () => {
      for (let i = 1; i < NUM_POINTS; i++) {
        if (dragging && i === NUM_POINTS - 1) continue;
        const p = pts[i];
        if (!p) continue;
        const vx = (p.x - p.oldx) * FRICTION;
        const vy = (p.y - p.oldy) * FRICTION;
        p.oldx = p.x;
        p.oldy = p.y;
        p.x += vx;
        p.y += vy + GRAVITY;
      }
      const pFirst = pts[0];
      if (pFirst) {
        pFirst.x = anchor.x;
        pFirst.y = anchor.y;
      }
      const pLast = pts[NUM_POINTS - 1];
      if (dragging && pLast) {
        pLast.x = ptr.x;
        pLast.y = ptr.y;
      }
      for (let iter = 0; iter < 6; iter++) {
        for (let i = 0; i < NUM_POINTS - 1; i++) {
          const p1 = pts[i];
          const p2 = pts[i + 1];
          if (!p1 || !p2) continue;
          const dx = p2.x - p1.x;
          const dy = p2.y - p1.y;
          const dist = Math.hypot(dx, dy) || 0.0001;
          const diff = ((SEG_LEN - dist) / dist) * 0.5;
          const ox = dx * diff;
          const oy = dy * diff;
          if (!p1.pinned) {
            p1.x -= ox;
            p1.y -= oy;
          }
          if (!(dragging && i + 1 === NUM_POINTS - 1)) {
            p2.x += ox;
            p2.y += oy;
          }
        }
      }
      for (let i = 1; i < NUM_POINTS; i++) {
        const pt = pts[i];
        if (pt) clamp(pt);
      }
    };

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const p0 = pts[0];
      const pLast = pts[NUM_POINTS - 1];
      if (!p0 || !pLast) return;

      const stroke = (style: string, width: number) => {
        ctx.beginPath();
        ctx.moveTo(p0.x, p0.y);
        for (let i = 1; i < NUM_POINTS - 1; i++) {
          const pi = pts[i];
          const pNext = pts[i + 1];
          if (!pi || !pNext) continue;
          ctx.quadraticCurveTo(pi.x, pi.y, (pi.x + pNext.x) / 2, (pi.y + pNext.y) / 2);
        }
        ctx.lineTo(pLast.x, pLast.y);
        ctx.strokeStyle = style;
        ctx.lineWidth = width;
        ctx.lineCap = "round";
        ctx.stroke();
      };
      ctx.save();
      ctx.translate(2, 4);
      ctx.globalAlpha = 0.22;
      stroke("#000000", 15);
      ctx.restore();
      stroke("#3D111A", 15);
      stroke("rgba(197, 155, 63, 0.45)", 15.5);
      stroke("#22070D", 12.5);
      stroke("rgba(244, 208, 111, 0.45)", 2.5);

      const mIdx = Math.floor(NUM_POINTS * 0.3);
      const pPrev = pts[mIdx - 1];
      const pNext = pts[mIdx + 1];
      const pMid = pts[mIdx];
      if (pPrev && pNext && pMid) {
        const angle = Math.atan2(pNext.y - pPrev.y, pNext.x - pPrev.x) + Math.PI / 2;
        ctx.save();
        ctx.translate(pMid.x, pMid.y);
        ctx.rotate(angle);
        ctx.strokeStyle = "rgba(197, 155, 63, 0.9)";
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(-4, 3.5);
        ctx.lineTo(0, -3.5);
        ctx.lineTo(4, 3.5);
        ctx.stroke();
        ctx.restore();
      }

      ctx.save();
      ctx.translate(anchor.x, anchor.y - 2);
      const g = ctx.createLinearGradient(-11, -9, 11, 9);
      g.addColorStop(0, "#F4D06F");
      g.addColorStop(0.35, "#C59B3F");
      g.addColorStop(0.65, "#9E7822");
      g.addColorStop(1, "#664C0E");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.rect(-11, -9, 22, 16);
      ctx.fill();
      ctx.strokeStyle = "rgba(61, 17, 26, 0.4)";
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.fillStyle = "#22070D";
      ctx.beginPath();
      ctx.arc(0, 0, 2.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    };

    const updateCard = () => {
      const last = pts[NUM_POINTS - 1];
      const prev = pts[NUM_POINTS - 2];
      if (!last || !prev) return;
      const ang = Math.atan2(last.y - prev.y, last.x - prev.x) - Math.PI / 2;
      card.style.left = `${last.x - card.offsetWidth / 2}px`;
      card.style.top = `${last.y}px`;
      card.style.transform = `rotate(${ang}rad)`;

      flipCurrent += (flipTarget - flipCurrent) * 0.16;
      if (!dragging && mouse.x > -1000) {
        const cx = card.offsetLeft + card.offsetWidth / 2;
        const cy = card.offsetTop + card.offsetHeight / 2;
        tilt.targetY = Math.max(-1, Math.min(1, (mouse.x - cx) / (card.offsetWidth / 2))) * 9;
        tilt.targetX = -Math.max(-1, Math.min(1, (mouse.y - cy) / (card.offsetHeight / 2))) * 9;
        card.style.setProperty("--mx", `${Math.max(0, Math.min(100, ((mouse.x - card.offsetLeft) / card.offsetWidth) * 100))}%`);
        card.style.setProperty("--my", `${Math.max(0, Math.min(100, ((mouse.y - card.offsetTop) / card.offsetHeight) * 100))}%`);
        card.classList.add("idcl-hovering");
      } else {
        tilt.targetX = 0;
        tilt.targetY = 0;
        card.classList.remove("idcl-hovering");
      }
      tilt.curX += (tilt.targetX - tilt.curX) * 0.12;
      tilt.curY += (tilt.targetY - tilt.curY) * 0.12;
      flipper.style.transform = `rotateY(${flipCurrent + tilt.curY}deg) rotateX(${tilt.curX}deg)`;
    };

    let raf = 0;
    const loop = () => {
      stepPhysics();
      draw();
      updateCard();
      raf = requestAnimationFrame(loop);
    };

    const onDown = (e: PointerEvent) => {
      const target = e.target as HTMLElement | null;
      if (target?.closest("a")) return;
      e.preventDefault();
      dragging = true;
      setInteracted(true);
      try {
        card.setPointerCapture(e.pointerId);
      } catch {
        // pointer capture fallback
      }
      const pos = getPos(e);
      clamp(pos);
      ptr = pos;
      lastPtr = pos;
      downPos = pos;
    };
    const onMove = (e: PointerEvent) => {
      mouse = getPos(e);
      if (!dragging) return;
      const pos = getPos(e);
      clamp(pos);
      vel.x = pos.x - lastPtr.x;
      vel.y = pos.y - lastPtr.y;
      lastPtr = pos;
      ptr = pos;
    };
    const onUp = () => {
      if (!dragging) return;
      dragging = false;
      if (Math.hypot(ptr.x - downPos.x, ptr.y - downPos.y) < 6) {
        flipped = !flipped;
        flipTarget = flipped ? 180 : 0;
      }
      const last = pts[NUM_POINTS - 1];
      if (last) {
        last.oldx = ptr.x - vel.x;
        last.oldy = ptr.y - vel.y;
      }
    };
    const onOut = (e: PointerEvent) => {
      if (e.relatedTarget === null) {
        mouse = { x: -9999, y: -9999 };
      }
    };

    card.addEventListener("pointerdown", onDown);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("resize", resize);
    document.addEventListener("pointerout", onOut);
    loop();

    return () => {
      cancelAnimationFrame(raf);
      card.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("resize", resize);
      document.removeEventListener("pointerout", onOut);
    };
  }, [anchorX, anchorY]);

  const rows = [
    { label: "ID NO", val: idNumber, icon: ICONS.id },
    { label: "DEPARTMENT", val: department, icon: ICONS.dept },
    { label: "LOCATION", val: location, icon: ICONS.loc },
    { label: "EMAIL", val: email, icon: ICONS.email },
    { label: "PHONE", val: phone, icon: ICONS.phone },
    { label: "VALID THRU", val: validThru, icon: ICONS.valid },
  ];

  const socials = [
    whatsappUrl && { href: whatsappUrl, label: "WhatsApp", icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" /></svg> },
    linkedinUrl && { href: linkedinUrl, label: "LinkedIn", icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" /><rect x={2} y={9} width={4} height={12} /><circle cx={4} cy={4} r={2} /></svg> },
    instagramUrl && { href: instagramUrl, label: "Instagram", icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><rect x={2} y={2} width={20} height={20} rx={5} ry={5} /><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" /><line x1={17.5} y1={6.5} x2={17.51} y2={6.5} /></svg> },
    githubUrl && { href: githubUrl, label: "GitHub", icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22" /></svg> },
  ].filter(Boolean) as Array<{ href: string; label: string; icon: React.ReactNode }>;

  const safeId = (idNumber || "001").replace(/[^a-zA-Z0-9]/g, "_");
  const socialTargetUrl = qrUrl || instagramUrl || whatsappUrl || "https://instagram.com";

  return (
    <div className={`idcl-root ${className}`} style={{ "--idcl-z": zIndex } as React.CSSProperties & Record<string, unknown>}>
      <style dangerouslySetInnerHTML={{ __html: CSS }} />

      <div className={`idcl-stage ${containerMode === "fixed" ? "idcl-fixed" : ""}`} ref={sceneRef}>
        <canvas className="idcl-rope" ref={canvasRef} />
        <div className="idcl-rail" ref={railRef} />

        <div className="idcl-card" ref={cardRef}>
          <div className="idcl-flipper" ref={flipperRef}>
            {/* Front Face */}
            <div className="idcl-face idcl-front">
              <svg className="idcl-bg-swoosh" viewBox="0 0 340 560" preserveAspectRatio="none" fill="none">
                <defs>
                  <linearGradient id={`goldSwoosh_${safeId}`} x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#EED799" stopOpacity="0.2" />
                    <stop offset="30%" stopColor="#C59B3F" stopOpacity="0.45" />
                    <stop offset="65%" stopColor="#9E7822" stopOpacity="0.75" />
                    <stop offset="100%" stopColor="#2D1A0D" stopOpacity="0.9" />
                  </linearGradient>
                  <linearGradient id={`goldVert_${safeId}`} x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#C59B3F" stopOpacity="0.85" />
                    <stop offset="70%" stopColor="#B88628" stopOpacity="0.7" />
                    <stop offset="100%" stopColor="#84601A" stopOpacity="0" />
                  </linearGradient>
                  <linearGradient id={`softWave_${safeId}`} x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#EFE3D0" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#C59B3F" stopOpacity="0.08" />
                  </linearGradient>
                </defs>
                <path d="M-20 60 Q 50 180 -10 320 Q -40 420 10 520" stroke={`url(#softWave_${safeId})`} strokeWidth={45} fill="none" opacity={0.6} />
                <line x1={324} y1={64} x2={324} y2={400} stroke={`url(#goldVert_${safeId})`} strokeWidth={3} strokeLinecap="round" />
                <path d="M 280 20 Q 320 80 324 160" stroke="#C59B3F" strokeWidth={1.5} strokeOpacity={0.3} fill="none" />
                <path d="M 340 370 Q 315 445 255 490 Q 195 535 90 550 L 340 560 Z" fill={`url(#goldSwoosh_${safeId})`} />
                <path d="M 340 365 Q 312 440 250 488 Q 190 533 80 549" stroke="#E6C26E" strokeWidth={1.8} fill="none" opacity={0.85} />
                <path d="M 340 440 Q 320 485 270 520 L 340 560 Z" fill="#241508" opacity={0.35} />
              </svg>

              <div className="idcl-hole" />

              <div className="idcl-face-content">
                <div className="idcl-header">
                  <div className="idcl-brand">
                    <svg className="idcl-brand-star" viewBox="0 0 24 24" fill="#C59B3F">
                      <path d="M12 0L14.5 9.5L24 12L14.5 14.5L12 24L9.5 14.5L0 12L9.5 9.5L12 0Z" />
                    </svg>
                    <div className="idcl-brand-text">
                      <b>{brand}</b>
                      <span className="idcl-brand-tagline">{brandTagline}</span>
                    </div>
                  </div>
                  <div className="idcl-pillars">
                    {pillars?.map((p) => <span key={p}>{p}</span>)}
                    <div className="idcl-pillars-line" />
                  </div>
                </div>

                <div className="idcl-photo-container">
                  <img src={photoUrl} alt={name} />
                  <div className="idcl-verified-badge" title="Verified">
                    <svg viewBox="0 0 24 24" width={14} height={14} fill="none" stroke="#FFFFFF" strokeWidth={3.5} strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </div>
                </div>

                <div className="idcl-identity">
                  <div className="idcl-name">{name}</div>
                  <div className="idcl-role">{role}</div>
                </div>

                <div className="idcl-info-section">
                  <div className="idcl-table">
                    {rows.map((r) => (
                      <div key={r.label} className="idcl-row">
                        <span className="idcl-row-icon">{r.icon}</span>
                        <span className="idcl-row-label">{r.label}</span>
                        <span className="idcl-row-sep">:</span>
                        <span className="idcl-row-val">{r.val}</span>
                      </div>
                    ))}
                  </div>

                  <div className="idcl-qr-col">
                    <a href={socialTargetUrl} target="_blank" rel="noopener noreferrer" className="idcl-qr-link" title="Click or scan to open social media">
                      <div className="idcl-qr-frame">
                        <UniqueScannableQR url={socialTargetUrl} />
                      </div>
                    </a>
                    <div className="idcl-qr-caption">SCAN FOR<br />SOCIAL</div>
                    <div className="idcl-qr-line" />
                  </div>
                </div>

                <div className="idcl-sig-section">
                  <div className="idcl-sig-script">{name}</div>
                  <div className="idcl-sig-label">AUTHORISED SIGNATURE</div>
                </div>

                <div className="idcl-card-footer">
                  <span className="idcl-footer-line" />
                  <span className="idcl-footer-text">WE PLAN</span>
                  <span className="idcl-footer-star">✦</span>
                  <span className="idcl-footer-text">YOU CELEBRATE</span>
                  <span className="idcl-footer-line" />
                </div>
              </div>
            </div>

            {/* Back Face */}
            <div className="idcl-face idcl-back">
              <div className="idcl-hole" />
              <div className="idcl-stripe" />

              <div className="idcl-idnum">
                <span>NO. {idNumber}</span>
                <em>{validThru} PASS</em>
              </div>

              <div className="idcl-barcode">
                {Array.from({ length: 28 }, (_, i) => (
                  <span key={i} style={{ height: (i * 37) % 100 > 40 ? "100%" : "55%" }} />
                ))}
              </div>

              <div className="idcl-backrow">
                <a href={socialTargetUrl} target="_blank" rel="noopener noreferrer" className="idcl-qr-link" title="Click or scan to open social media">
                  <div className="idcl-qr-frame qr-back">
                    <UniqueScannableQR url={socialTargetUrl} />
                  </div>
                </a>
                <div className="idcl-scan">
                  <b>THE PLANNER BROZ VIP</b>
                  <span className="idcl-scan-url">{site}</span>
                  <br />
                  <span className="idcl-scan-prompt">Scan with phone camera to connect on Social Media.</span>
                </div>
              </div>

              {socials.length > 0 && (
                <div className="idcl-connect">
                  <span>Connect</span>
                  <div className="idcl-connect-icons">
                    {socials.map((s) => (
                      <a key={s.label} href={s.href} target="_blank" rel="noopener noreferrer" aria-label={s.label}>
                        {s.icon}
                      </a>
                    ))}
                  </div>
                </div>
              )}

              <div className="idcl-sig">
                <div className="idcl-script">{name}</div>
                <small>Authorized Co-Founder Signature</small>
              </div>
            </div>
          </div>
        </div>

        {showHint && (
          <div className={`idcl-hint ${interacted ? "idcl-hint-hidden" : ""}`}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
              <path d="M12 3v18M7 8l-4 4 4 4M17 8l4 4-4 4" />
            </svg>
            Drag to swing · Click to flip
          </div>
        )}
      </div>
    </div>
  );
}

export default IDCardLanyard;
