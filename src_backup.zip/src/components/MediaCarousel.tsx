import React, { useState, useEffect, useRef } from 'react';
import { MediaItem } from '../data/servicesData';

interface MediaCarouselProps {
  photos: MediaItem[];
  videos: MediaItem[];
  viewAllText: string;
  viewAllLink: string;
  autoSlideSpeed?: number;
  reverseDirection?: boolean;
}

export const MediaCarousel: React.FC<MediaCarouselProps> = ({
  photos,
  videos,
  viewAllText,
  viewAllLink,
  autoSlideSpeed = 2400,
  reverseDirection = false,
}) => {
  const [activeTab, setActiveTab] = useState<'photos' | 'videos'>('photos');
  const [activeIndex, setActiveIndex] = useState<number>(2);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [activeVideoSrc, setActiveVideoSrc] = useState<string | null>(null);
  const [activePhotoIndex, setActivePhotoIndex] = useState<number | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'spotlight'>('grid');
  const [spotlightIndex, setSpotlightIndex] = useState<number>(0);

  const items = activeTab === 'photos' ? photos : videos;
  const activePhotoItem = activePhotoIndex !== null ? items[activePhotoIndex] : null;
  const galleryPhotos = activePhotoItem?.gallery && activePhotoItem.gallery.length > 0
    ? activePhotoItem.gallery
    : (activePhotoItem ? [{ src: activePhotoItem.src, title: activePhotoItem.title, desc: activePhotoItem.subtitle || activePhotoItem.alt }] : []);

  const touchStartXRef = useRef<number>(0);
  const touchEndXRef = useRef<number>(0);
  const isDraggingRef = useRef<boolean>(false);

  // Auto-slide effect (continuous smooth glide)
  useEffect(() => {
    if (isPaused || activeVideoSrc || activePhotoIndex !== null) return;

    const timer = setInterval(() => {
      setActiveIndex((prev) => {
        if (reverseDirection) {
          return (prev - 1 + items.length) % items.length;
        } else {
          return (prev + 1) % items.length;
        }
      });
    }, autoSlideSpeed);

    return () => clearInterval(timer);
  }, [items.length, autoSlideSpeed, reverseDirection, isPaused, activeVideoSrc, activePhotoIndex]);

  // Keyboard navigation for gallery modal
  useEffect(() => {
    if (activePhotoIndex === null) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setActivePhotoIndex(null);
      if (viewMode === 'spotlight' && galleryPhotos.length > 0) {
        if (e.key === 'ArrowLeft') {
          setSpotlightIndex((prev) => (prev - 1 + galleryPhotos.length) % galleryPhotos.length);
        }
        if (e.key === 'ArrowRight') {
          setSpotlightIndex((prev) => (prev + 1) % galleryPhotos.length);
        }
      }
      if (e.key === 'g' || e.key === 'G') {
        setViewMode((prev) => (prev === 'grid' ? 'spotlight' : 'grid'));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activePhotoIndex, viewMode, galleryPhotos.length]);

  // Reset active index when switching tabs
  const handleSwitchTab = (tab: 'photos' | 'videos') => {
    setActiveTab(tab);
    setActiveIndex(2);
    setActivePhotoIndex(null);
    setActiveVideoSrc(null);
  };

  const handlePrev = () => {
    setActiveIndex((prev) => (prev - 1 + items.length) % items.length);
  };

  const handleNext = () => {
    setActiveIndex((prev) => (prev + 1) % items.length);
  };

  const handleCardClick = (index: number, item: MediaItem) => {
    setActiveIndex(index);

    if (item.type === 'image') {
      setActivePhotoIndex(index);
      setViewMode('grid');
      setSpotlightIndex(0);
    } else if (item.type === 'video' && item.src) {
      setActiveVideoSrc(item.src);
    }
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
    setIsPaused(true);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    touchEndXRef.current = e.changedTouches[0].clientX;
    handleSwipe();
    setIsPaused(false);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.tpb-carousel-nav-btn')) return;
    isDraggingRef.current = true;
    touchStartXRef.current = e.clientX;
    setIsPaused(true);
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;
    touchEndXRef.current = e.clientX;
    handleSwipe();
    setIsPaused(false);
  };

  const handleSwipe = () => {
    const diff = touchEndXRef.current - touchStartXRef.current;
    if (Math.abs(diff) > 35) {
      if (diff > 0) {
        handlePrev();
      } else {
        handleNext();
      }
    }
  };

  return (
    <>
      {/* 1. Header with Tabs & View All */}
      <div className="tpb-carousel-header">
        <div className="tpb-tabs-container">
          <button
            type="button"
            className={`tpb-tab-btn ${activeTab === 'photos' ? 'active' : ''}`}
            onClick={() => handleSwitchTab('photos')}
          >
            <i className="bi bi-images"></i>
            <span>Photos</span>
          </button>
          <button
            type="button"
            className={`tpb-tab-btn ${activeTab === 'videos' ? 'active' : ''}`}
            onClick={() => handleSwitchTab('videos')}
          >
            <i className="bi bi-play-circle-fill"></i>
            <span>Videos</span>
          </button>
        </div>

        <a href={viewAllLink} className="tpb-view-all-link">
          <span>{viewAllText}</span>
          <i className="bi bi-arrow-right"></i>
        </a>
      </div>

      {/* 2. 3D Rubber-Band Carousel Viewport with 3-Point Arch Wave */}
      <div
        className="tpb-carousel-stage"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
      >
        {/* Navigation Arrows */}
        <button
          type="button"
          className="tpb-carousel-nav-btn prev-btn"
          onClick={handlePrev}
          aria-label="Previous Slide"
        >
          <i className="bi bi-chevron-left"></i>
        </button>
        <button
          type="button"
          className="tpb-carousel-nav-btn next-btn"
          onClick={handleNext}
          aria-label="Next Slide"
        >
          <i className="bi bi-chevron-right"></i>
        </button>

        {/* 3D Depth Cards along the Arch */}
        <div
          className="tpb-cards-wrapper"
          style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {items.map((item, index) => {
            const isVideo = item.type === 'video';
            const imageSrc = isVideo ? (item.poster || item.src) : item.src;

            // Calculate offset relative to activeIndex
            let diff = index - activeIndex;
            while (diff > items.length / 2) diff -= items.length;
            while (diff < -items.length / 2) diff += items.length;

            let posClass = 'tpb-carousel-card';
            if (diff === 0) posClass += ' pos-center';
            else if (diff === -1) posClass += ' pos-left-1';
            else if (diff === 1) posClass += ' pos-right-1';
            else if (diff === -2) posClass += ' pos-left-2';
            else if (diff === 2) posClass += ' pos-right-2';
            else if (diff < -2) posClass += ' pos-hidden-left';
            else if (diff > 2) posClass += ' pos-hidden-right';

            return (
              <div
                key={`${item.title}-${index}`}
                className={posClass}
                data-offset={diff}
                onClick={() => handleCardClick(index, item)}
                title={`Click to view ${isVideo ? 'video' : 'photo'}`}
              >
                <div className="tpb-card-media-box">
                  <img src={imageSrc} alt={item.alt || item.title} loading="lazy" />
                  {isVideo ? (
                    <div className="tpb-play-overlay">
                      <i className="bi bi-play-fill"></i>
                    </div>
                  ) : (
                    <div className="tpb-pop-hint">
                      <i className="bi bi-arrows-fullscreen"></i>
                    </div>
                  )}
                </div>
                <div className="tpb-card-title">{item.title}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. Pagination Dots */}
      <div className="tpb-dots-wrapper">
        {items.map((_, index) => (
          <button
            key={`dot-${index}`}
            type="button"
            className={`tpb-dot ${index === activeIndex ? 'active' : ''}`}
            onClick={() => setActiveIndex(index)}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      {/* 4. Luxury Full-Width Photo Gallery Pop-Up Modal */}
      {activePhotoIndex !== null && activePhotoItem && (
        <div
          className="tpb-gallery-modal-backdrop active"
          onClick={() => setActivePhotoIndex(null)}
        >
          <div
            className="tpb-gallery-modal-window"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-label="Bespoke Photo Gallery"
          >
            {/* Header */}
            <div className="tpb-gallery-header">
              <div className="tpb-gallery-header-left">
                <div className="tpb-gallery-badge-row">
                  <span className="tpb-gallery-badge">✦ THE PLANNER BROZ BESPOKE GALLERY</span>
                </div>
                <h3 className="tpb-gallery-title">{activePhotoItem.title}</h3>
                <p className="tpb-gallery-subtitle">
                  {activePhotoItem.subtitle || activePhotoItem.alt || 'Explore our curated photo moments and bespoke highlights'}
                </p>
              </div>

              <div className="tpb-gallery-header-right">
                <span className="tpb-gallery-count-pill">
                  <i className="bi bi-images"></i>
                  <span>{galleryPhotos.length} Curated Photos</span>
                </span>

                <div className="tpb-gallery-view-switcher">
                  <button
                    type="button"
                    className={`tpb-gallery-view-btn ${viewMode === 'grid' ? 'active' : ''}`}
                    onClick={() => setViewMode('grid')}
                    title="Show all photos in gallery grid"
                  >
                    <i className="bi bi-grid-3x3-gap-fill"></i>
                    <span>Grid View</span>
                  </button>
                  <button
                    type="button"
                    className={`tpb-gallery-view-btn ${viewMode === 'spotlight' ? 'active' : ''}`}
                    onClick={() => setViewMode('spotlight')}
                    title="View featured slideshow with filmstrip"
                  >
                    <i className="bi bi-aspect-ratio"></i>
                    <span>Spotlight</span>
                  </button>
                </div>

                <button
                  type="button"
                  className="tpb-gallery-close-btn"
                  onClick={() => setActivePhotoIndex(null)}
                  aria-label="Close Gallery"
                >
                  <i className="bi bi-x-lg"></i>
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="tpb-gallery-body">
              {viewMode === 'grid' ? (
                <div className="tpb-gallery-grid-view">
                  <div className="tpb-gallery-grid">
                    {galleryPhotos.map((gItem, idx) => (
                      <div
                        key={`grid-item-${idx}`}
                        className="tpb-gallery-card"
                        onClick={() => {
                          setSpotlightIndex(idx);
                          setViewMode('spotlight');
                        }}
                        title="Click to view full spotlight"
                      >
                        <div className="tpb-gallery-card-img-wrap">
                          <img src={gItem.src} alt={gItem.title} loading="lazy" />
                        </div>
                        <div className="tpb-gallery-card-gradient"></div>
                        <div className="tpb-gallery-card-pop-icon">
                          <i className="bi bi-arrows-angle-expand"></i>
                        </div>
                        <div className="tpb-gallery-card-content">
                          <span className="tpb-gallery-card-index">✦ MOMENT 0${idx + 1}</span>
                          <h4 className="tpb-gallery-card-title">{gItem.title}</h4>
                          {gItem.desc && <p className="tpb-gallery-card-desc">{gItem.desc}</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="tpb-gallery-spotlight-view active">
                  <div className="tpb-spotlight-stage">
                    <button
                      type="button"
                      className="tpb-spotlight-nav-btn prev-btn"
                      onClick={() =>
                        setSpotlightIndex((prev) => (prev - 1 + galleryPhotos.length) % galleryPhotos.length)
                      }
                      aria-label="Previous Photo"
                    >
                      <i className="bi bi-chevron-left"></i>
                    </button>
                    <button
                      type="button"
                      className="tpb-spotlight-nav-btn next-btn"
                      onClick={() =>
                        setSpotlightIndex((prev) => (prev + 1) % galleryPhotos.length)
                      }
                      aria-label="Next Photo"
                    >
                      <i className="bi bi-chevron-right"></i>
                    </button>

                    {galleryPhotos[spotlightIndex] && (
                      <img
                        src={galleryPhotos[spotlightIndex].src}
                        alt={galleryPhotos[spotlightIndex].title}
                      />
                    )}

                    <div className="tpb-spotlight-info-bar">
                      <div className="tpb-spotlight-text">
                        <span className="tpb-spotlight-counter">
                          Photo {spotlightIndex + 1} of {galleryPhotos.length}
                        </span>
                        <h4 className="tpb-spotlight-title">
                          {galleryPhotos[spotlightIndex]?.title}
                        </h4>
                        <p className="tpb-spotlight-desc">
                          {galleryPhotos[spotlightIndex]?.desc || activePhotoItem.subtitle}
                        </p>
                      </div>
                      <button
                        type="button"
                        className="tpb-back-grid-btn"
                        onClick={() => setViewMode('grid')}
                      >
                        <i className="bi bi-grid-3x3-gap-fill"></i>
                        <span>Back to Gallery Grid</span>
                      </button>
                    </div>
                  </div>

                  {/* Thumbnail Filmstrip */}
                  <div className="tpb-gallery-filmstrip-wrap">
                    <div className="tpb-gallery-filmstrip">
                      {galleryPhotos.map((gItem, idx) => (
                        <div
                          key={`thumb-${idx}`}
                          className={`tpb-filmstrip-thumb ${idx === spotlightIndex ? 'active' : ''}`}
                          onClick={() => setSpotlightIndex(idx)}
                          title={gItem.title}
                        >
                          <img src={gItem.src} alt={gItem.title} />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 5. Luxury Video Lightbox Modal */}
      {activeVideoSrc && (
        <div
          className="tpb-video-modal-backdrop active"
          onClick={() => setActiveVideoSrc(null)}
        >
          <div
            className="tpb-video-modal-window"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              className="tpb-video-close-btn"
              onClick={() => setActiveVideoSrc(null)}
              aria-label="Close Video"
            >
              <i className="bi bi-x-lg"></i>
            </button>
            <video src={activeVideoSrc} controls autoPlay playsInline />
          </div>
        </div>
      )}
    </>
  );
};

export default MediaCarousel;
