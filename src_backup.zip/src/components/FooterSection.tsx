import { CONTACT_INFO } from '../data';

/* 
=========================================================================================
9. FOOTER SECTION COMPONENT
- Top CTA: "Plan Your Experience"
- Giant "PLANNER BROZ" Typography Watermark
- Bottom Contact Information & Legal Policies
- Full Width with Mehroom Background
=========================================================================================
*/

interface FooterSectionProps {
  onPlanYourStay?: () => void;
  onSocialClick?: (platform: string) => void;
  onLegalClick?: (doc: string) => void;
}

export default function FooterSection({
  onPlanYourStay,
  onLegalClick,
}: FooterSectionProps) {
  const handlePlanClick = () => {
    if (onPlanYourStay) {
      onPlanYourStay();
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <footer 
      id="footer-section" 
      className="w-100 p-0 m-0"
      style={{
        background: 'linear-gradient(180deg, #240A10 0%, #1A060B 60%, #120306 100%)',
        borderTop: '1px solid rgba(197, 155, 63, 0.25)',
        color: '#ffffff'
      }}
    >
      <div 
        className="footer-container"
        style={{
          background: 'transparent',
          padding: '65px 24px 35px 24px',
          maxWidth: '1200px',
          margin: '0 auto',
          width: '100%'
        }}
      >
        {/* Top CTA Area */}
        <div className="text-center mx-auto mb-5" style={{ maxWidth: '640px' }}>
          <span 
            className="badge rounded-pill px-3 py-2 mb-3" 
            style={{ 
              background: 'rgba(255,255,255,0.1)', 
              color: 'var(--brand-gold-light, #F4D06F)', 
              border: '1px solid rgba(197,155,63,0.35)',
              fontSize: '12px'
            }}
          >
            ✨ Bespoke Celebrations &amp; Stays
          </span>
          <h2 id="footer-cta-title" className="h1 fw-bold text-white mb-3">
            Discover Places You&apos;ll<br />Never Want to Leave
          </h2>
          <p id="footer-cta-desc" className="text-white-50 small mb-4">
            Your next great experience is waiting. We plan every single detail so you can celebrate without stress.
          </p>
          <button
            id="footer-plan-stay-btn"
            type="button"
            onClick={handlePlanClick}
            className="btn btn-gold px-5 py-3 rounded-pill fw-bold text-white shadow-sm"
          >
            <span>Plan Your Experience</span>
            <i className="bi bi-arrow-up-right ms-2"></i>
          </button>
        </div>

        {/* Giant Watermark Brand Logo */}
        <div 
          className="footer-huge-logo text-center my-4 my-md-5"
          style={{
            textAlign: 'center',
            width: '100%',
            display: 'block',
            whiteSpace: 'nowrap'
          }}
        >
          THE PLANNER BROZ
        </div>

        {/* Bottom Contact & Legal Info (Cleanly aligned) */}
        <div 
          className="row pt-4 text-white-50 small g-3 align-items-center"
          style={{ borderTop: '1px solid rgba(197, 155, 63, 0.25)' }}
        >
          {/* Left: Contact Info */}
          <div className="col-12 col-md-6 text-center text-md-start">
            <div className="text-white fw-bold fs-6">{CONTACT_INFO.brandName}</div>
            <div style={{ color: 'var(--brand-gold-light, #F4D06F)' }} className="fst-italic mb-2">
              {CONTACT_INFO.tagline}
            </div>
            <div>
              Email: <a href={`mailto:${CONTACT_INFO.email}`} style={{ color: '#F4D06F' }} className="text-decoration-none">{CONTACT_INFO.email}</a>
            </div>
            <div>Phone: {CONTACT_INFO.phone}</div>
          </div>

          {/* Right: Copyright & Legal */}
          <div className="col-12 col-md-6 text-center text-md-end">
            <div>&copy; 2026 {CONTACT_INFO.brandName}. All Rights Reserved.</div>
            <div className="mt-2 d-flex flex-wrap justify-content-center justify-content-md-end gap-3">
              {CONTACT_INFO.legal.map((doc, idx) => (
                <span key={doc} className="d-inline-flex align-items-center gap-3">
                  <button
                    type="button"
                    onClick={() => onLegalClick?.(doc)}
                    className="btn btn-link p-0 text-white-50 text-decoration-none small"
                  >
                    {doc}
                  </button>
                  {idx < CONTACT_INFO.legal.length - 1 && <span className="text-white-50 d-none d-md-inline">•</span>}
                </span>
              ))}
            </div>
          </div>
        </div>

      </div>
    </footer>
  );
}
