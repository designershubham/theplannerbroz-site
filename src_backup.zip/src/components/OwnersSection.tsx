import { IDCardLanyard } from './ui/id-card-lanyard';

export default function OwnersSection() {
  return (
    <section id="ownersSection" className="py-5 position-relative overflow-hidden" style={{ backgroundColor: '#FAF7F2' }}>

      {/* Subtle Background Glows */}
      <div
        className="position-absolute rounded-circle"
        style={{
          top: '-10%',
          left: '15%',
          width: '420px',
          height: '420px',
          background: 'radial-gradient(circle, rgba(197, 155, 63, 0.12) 0%, transparent 70%)',
          pointerEvents: 'none'
        }}
      />
      <div
        className="position-absolute rounded-circle"
        style={{
          bottom: '-10%',
          right: '15%',
          width: '450px',
          height: '450px',
          background: 'radial-gradient(circle, rgba(61, 17, 26, 0.08) 0%, transparent 70%)',
          pointerEvents: 'none'
        }}
      />

      <div className="container px-4 px-lg-5 position-relative" style={{ zIndex: 2, maxWidth: '1240px' }}>

        {/* Section Header */}
        <div className="text-center mb-5">
          <div className="d-inline-flex align-items-center gap-2 mb-2">
            <span style={{ width: 8, height: 8, borderRadius: '50%', backgroundColor: 'var(--brand-gold, #C59B3F)' }} />
            <span style={{ fontSize: '13px', fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#685E58' }}>
              LEADERSHIP &amp; FOUNDERS
            </span>
            <span style={{ width: 32, height: 1.5, backgroundColor: 'var(--brand-gold, #C59B3F)' }} />
          </div>

          <h2
            className="fw-bold mb-3"
            style={{
              fontFamily: "'Playfair Display', Georgia, serif",
              fontSize: 'clamp(2.1rem, 3.8vw, 3.2rem)',
              color: '#22070D',
              letterSpacing: '-0.02em'
            }}
          >
            The Minds Behind <span style={{ color: '#C59B3F', fontStyle: 'italic' }}>The Magic</span>
          </h2>

          <p className="mx-auto" style={{ maxWidth: '640px', fontSize: '15.5px', color: '#685E58', lineHeight: 1.7 }}>
            Meet the two co-founders behind <strong>The Planner Broz</strong> — uniting flawless operational planning with immersive luxury travel &amp; bespoke celebrations.
          </p>

          <div className="d-inline-flex align-items-center gap-2 mt-2 px-3 py-1 rounded-pill" style={{ background: 'rgba(197, 155, 63, 0.12)', border: '1px solid rgba(197, 155, 63, 0.3)' }}>
            <span style={{ color: '#C59B3F', fontSize: '14px' }}>✦</span>
            <span style={{ fontSize: '12px', fontWeight: 600, color: '#3D111A' }}>
              Interactive VIP Lanyards: Drag to swing card · Click to flip for Social QR &amp; Signature
            </span>
            <span style={{ color: '#C59B3F', fontSize: '14px' }}>✦</span>
          </div>
        </div>

        {/* 2 ID Cards Display Grid */}
        <div className="row g-4 justify-content-center">

          {/* Founder 1: Aryan Sharma */}
          <div className="col-12 col-lg-6">
            <div
              className="p-4 rounded-4 position-relative d-flex flex-column align-items-center"
              style={{
                background: 'linear-gradient(180deg, #FFFFFF 0%, #FAF5EE 100%)',
                border: '1px solid rgba(197, 155, 63, 0.28)',
                boxShadow: '0 18px 42px rgba(34, 7, 13, 0.06)',
                minHeight: '680px'
              }}
            >
              {/* Top Meta Tag */}
              <div className="d-flex justify-content-between align-items-center w-100 mb-3 px-2">
                <span className="badge px-3 py-2 rounded-pill" style={{ background: '#3D111A', color: '#F4D06F', fontWeight: 600, fontSize: '11px', letterSpacing: '0.08em' }}>
                  CO-FOUNDER · TPB-001
                </span>
                <span className="small text-muted fw-semibold" style={{ fontSize: '11.5px' }}>
                  OPERATIONS &amp; PLANNING
                </span>
              </div>

              {/* Lanyard Card Stage */}
              <div className="position-relative w-100 flex-grow-1" style={{ height: '560px' }}>
                <IDCardLanyard
                  name="Aryan Sharma"
                  role="Co-Founder & Managing Director"
                  brand="THE PLANNER BROZ"
                  brandTagline="Luxury Experiences & Events"
                  pillars={["Vision", "Plan", "Execute"]}
                  location="New Delhi · Mumbai"
                  idNumber="TPB-001"
                  validThru="Lifetime"
                  site="theplannerbroz.com"
                  photoUrl="/assets/founder-aryan.jpg"
                  email="aryan@theplannerbroz.com"
                  linkedinUrl="https://linkedin.com"
                  instagramUrl="https://instagram.com"
                  whatsappUrl="https://wa.me/919876543210"
                  anchorX="50%"
                  anchorY={8}
                  containerMode="relative"
                  zIndex={5}
                />
              </div>

              {/* Bottom Quick Bio */}
              <div className="w-100 text-center pt-3 border-top" style={{ borderColor: 'rgba(197, 155, 63, 0.2)' }}>
                <h5 className="fw-bold mb-1" style={{ color: '#22070D', fontSize: '17px' }}>Aryan Sharma</h5>
                <p className="small text-muted mb-2">Mastermind behind large-scale celebration timelines, luxury logistics &amp; vendor excellence.</p>
                <div className="d-flex justify-content-center gap-2">
                  <a
                    href="https://wa.me/919876543210"
                    target="_blank"
                    rel="noreferrer"
                    className="btn btn-sm px-3 rounded-pill"
                    style={{ background: '#3D111A', color: '#F4D06F', fontSize: '12px', fontWeight: 600 }}
                  >
                    Direct WhatsApp
                  </a>
                </div>
              </div>

            </div>
          </div>

          {/* Founder 2: Kabir Sharma */}
          <div className="col-12 col-lg-6">
            <div
              className="p-4 rounded-4 position-relative d-flex flex-column align-items-center"
              style={{
                background: 'linear-gradient(180deg, #FFFFFF 0%, #FAF5EE 100%)',
                border: '1px solid rgba(197, 155, 63, 0.28)',
                boxShadow: '0 18px 42px rgba(34, 7, 13, 0.06)',
                minHeight: '680px'
              }}
            >
              {/* Top Meta Tag */}
              <div className="d-flex justify-content-between align-items-center w-100 mb-3 px-2">
                <span className="badge px-3 py-2 rounded-pill" style={{ background: '#C59B3F', color: '#22070D', fontWeight: 700, fontSize: '11px', letterSpacing: '0.08em' }}>
                  CO-FOUNDER · TPB-002
                </span>
                <span className="small text-muted fw-semibold" style={{ fontSize: '11.5px' }}>
                  CREATIVE &amp; LUXURY STAYS
                </span>
              </div>

              {/* Lanyard Card Stage */}
              <div className="position-relative w-100 flex-grow-1" style={{ height: '560px' }}>
                <IDCardLanyard
                  name="Kabir Sharma"
                  role="Co-Founder & Creative Director"
                  brand="THE PLANNER BROZ"
                  brandTagline="Luxury Experiences & Events"
                  pillars={["Curate", "Design", "Elevate"]}
                  location="Goa · Jaipur"
                  idNumber="TPB-002"
                  validThru="Lifetime"
                  site="theplannerbroz.com"
                  photoUrl="/assets/founder-kabir.jpg"
                  email="kabir@theplannerbroz.com"
                  linkedinUrl="https://linkedin.com"
                  instagramUrl="https://instagram.com"
                  whatsappUrl="https://wa.me/919876543210"
                  anchorX="50%"
                  anchorY={8}
                  containerMode="relative"
                  zIndex={5}
                />
              </div>

              {/* Bottom Quick Bio */}
              <div className="w-100 text-center pt-3 border-top" style={{ borderColor: 'rgba(197, 155, 63, 0.2)' }}>
                <h5 className="fw-bold mb-1" style={{ color: '#22070D', fontSize: '17px' }}>Kabir Sharma</h5>
                <p className="small text-muted mb-2">Curator of bespoke destination experiences, private villas, aesthetic themes &amp; guest memories.</p>
                <div className="d-flex justify-content-center gap-2">
                  <a
                    href="https://wa.me/919876543210"
                    target="_blank"
                    rel="noreferrer"
                    className="btn btn-sm px-3 rounded-pill"
                    style={{ background: '#C59B3F', color: '#22070D', fontSize: '12px', fontWeight: 700 }}
                  >
                    Direct WhatsApp
                  </a>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
