import { useEffect, useRef } from 'react';
import { HERO_DATA } from '../data';

/* 
=========================================================================================
2. HERO SECTION COMPONENT (WITH SCROLL-BASED 300-FRAME ANIMATION)
- 300-Frame Scroll Canvas Background
- Soft gradient overlay for text legibility
- Left column width (~45% col-lg-6 col-xl-5), strictly left-aligned
- Tagline badge with gold star
- Refined headline "WE TURN IDEAS INTO EXPERIENCES." (font-weight: 500)
- Animated "Check Now" button with arrow bubble
- Social proof metrics row
- Right column empty with animation visible
=========================================================================================
*/

interface HeroProps {
  onCheckNow?: () => void;
  onExploreExperience?: () => void;
}

export default function Hero({ onCheckNow, onExploreExperience }: HeroProps) {
  const trackRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const heroTrack = trackRef.current;
    const canvas = canvasRef.current;
    if (!heroTrack || !canvas) return;

    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    const TOTAL_FRAMES = 300;
    const images: HTMLImageElement[] = new Array(TOTAL_FRAMES);
    const loadedMap = new Uint8Array(TOTAL_FRAMES);

    let currentFrame = 0;
    let targetFrame = 0;
    let lastRenderedIndex = -1;
    let animId: number;
    let isHeroVisible = true;
    let cw = 0;
    let ch = 0;

    function getFrameUrl(index: number) {
      const num = String(index + 1).padStart(3, '0');
      return `frames/ezgif-frame-${num}.jpg`;
    }

    function resizeCanvas() {
      if (!canvas || !canvas.parentElement) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = canvas.parentElement.clientWidth || window.innerWidth;
      const h = canvas.parentElement.clientHeight || window.innerHeight;

      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      cw = canvas.width;
      ch = canvas.height;

      lastRenderedIndex = -1;
      updateScrollProgress();
    }

    function drawImageToCanvas(img: HTMLImageElement) {
      if (!ctx || !canvas || !img || !img.complete || img.naturalWidth === 0) return;

      const iw = img.naturalWidth;
      const ih = img.naturalHeight;

      const hRatio = cw / iw;
      const vRatio = ch / ih;
      
      // 8% overscan zoom pushes any bottom-right corner watermark/logo completely outside canvas bounds
      const OVER_SCAN = 1.08;
      const ratio = Math.max(hRatio, vRatio) * OVER_SCAN;

      const nw = iw * ratio;
      const nh = ih * ratio;
      
      // Bias offset by 30px so the bottom-right corner is pushed 90-100px past the canvas edge
      const nx = (cw - nw) / 2 - 30;
      const ny = (ch - nh) / 2 - 25;

      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'medium';
      ctx.drawImage(img, nx, ny, nw, nh);
    }

    function loadFrame(i: number, onLoaded?: (idx: number, img: HTMLImageElement) => void) {
      if (i < 0 || i >= TOTAL_FRAMES || images[i]) return;
      const img = new Image();
      images[i] = img;
      img.onload = () => {
        loadedMap[i] = 1;
        if (onLoaded) onLoaded(i, img);
        const desired = Math.min(TOTAL_FRAMES - 1, Math.max(0, Math.round(currentFrame)));
        if (lastRenderedIndex === -1 || Math.abs(desired - i) < Math.abs(desired - lastRenderedIndex)) {
          drawImageToCanvas(img);
          lastRenderedIndex = i;
        }
      };
      img.src = getFrameUrl(i);
    }

    function prioritizeNearbyFrames(center: number) {
      const radius = 16;
      for (let r = 1; r <= radius; r++) {
        const ahead = center + r;
        const behind = center - r;
        if (ahead < TOTAL_FRAMES && !images[ahead]) loadFrame(ahead);
        if (behind >= 0 && !images[behind]) loadFrame(behind);
      }
    }

    function initSmartPreloader() {
      loadFrame(0, (_, img) => {
        if (lastRenderedIndex === -1) {
          drawImageToCanvas(img);
          lastRenderedIndex = 0;
        }
      });

      let skeletonIndex = 0;
      const skeletonStep = 5;
      function loadSkeletonBatch() {
        const end = Math.min(skeletonIndex + 15, TOTAL_FRAMES);
        for (let i = skeletonIndex; i < end; i += skeletonStep) {
          loadFrame(i);
        }
        skeletonIndex = end;
        if (skeletonIndex < TOTAL_FRAMES) {
          setTimeout(loadSkeletonBatch, 20);
        } else {
          loadRemainingFrames(1);
        }
      }
      setTimeout(loadSkeletonBatch, 40);

      function loadRemainingFrames(start: number) {
        let idx = start;
        function fillBatch() {
          let loadedInBatch = 0;
          while (idx < TOTAL_FRAMES && loadedInBatch < 10) {
            if (!images[idx]) {
              loadFrame(idx);
              loadedInBatch++;
            }
            idx++;
          }
          if (idx < TOTAL_FRAMES) {
            setTimeout(fillBatch, 40);
          }
        }
        setTimeout(fillBatch, 150);
      }
    }

    const heroText = document.querySelector('.hero-content-container') as HTMLElement | null;
    const heroOverlay = document.querySelector('.hero-content-overlay') as HTMLElement | null;

    function updateScrollProgress() {
      if (!heroTrack) return;
      const scrollY = window.scrollY || window.pageYOffset || 0;
      const viewport = canvas?.parentElement;

      // Hide fixed hero when completely covered by mainContentLayer to save GPU
      if (scrollY > heroTrack.offsetHeight + 100) {
        if (isHeroVisible && viewport) {
          viewport.style.visibility = 'hidden';
          isHeroVisible = false;
        }
        return;
      } else {
        if (!isHeroVisible && viewport) {
          viewport.style.visibility = 'visible';
          isHeroVisible = true;
        }
      }

      const totalScroll = heroTrack.offsetHeight - window.innerHeight;
      if (totalScroll <= 0) {
        targetFrame = 0;
        return;
      }
      const progress = Math.min(Math.max(scrollY / totalScroll, 0), 1);
      targetFrame = progress * (TOTAL_FRAMES - 1);

      prioritizeNearbyFrames(Math.round(targetFrame));
    }

    function render() {
      if (isHeroVisible) {
        const diff = targetFrame - currentFrame;
        if (Math.abs(diff) > 0.002) {
          currentFrame += diff * 0.085;
        } else {
          currentFrame = targetFrame;
        }

        // Frame-based smooth dissolve: text & overlay are visible only on initial 5-10 frames, hidden thereafter
        if (heroText) {
          const FADE_START = 4;
          const FADE_END = 12;
          let textAlpha = 1;

          if (currentFrame <= FADE_START) {
            textAlpha = 1;
          } else if (currentFrame >= FADE_END) {
            textAlpha = 0;
          } else {
            const t = (currentFrame - FADE_START) / (FADE_END - FADE_START);
            textAlpha = 1 - (t * t * (3 - 2 * t)); // smoothstep easing
          }

          if (textAlpha <= 0.002) {
            if (heroText.style.visibility !== 'hidden') {
              heroText.style.opacity = '0';
              heroText.style.visibility = 'hidden';
              heroText.style.pointerEvents = 'none';
              heroText.style.transform = 'translateY(-20px)';
            }
            if (heroOverlay && heroOverlay.style.opacity !== '0') {
              heroOverlay.style.opacity = '0';
            }
          } else {
            heroText.style.visibility = 'visible';
            heroText.style.opacity = textAlpha.toFixed(3);
            heroText.style.pointerEvents = (textAlpha > 0.3) ? 'auto' : 'none';
            heroText.style.transform = `translateY(${(-20 * (1 - textAlpha)).toFixed(1)}px)`;
            if (heroOverlay) {
              heroOverlay.style.opacity = textAlpha.toFixed(3);
            }
          }
        }

        const desiredIndex = Math.min(TOTAL_FRAMES - 1, Math.max(0, Math.round(currentFrame)));

        let bestImg: HTMLImageElement | null = null;
        let bestIndex = -1;

        if (images[desiredIndex] && loadedMap[desiredIndex]) {
          bestImg = images[desiredIndex];
          bestIndex = desiredIndex;
        } else {
          for (let offset = 1; offset < TOTAL_FRAMES; offset++) {
            const left = desiredIndex - offset;
            const right = desiredIndex + offset;
            if (left >= 0 && images[left] && loadedMap[left]) {
              bestImg = images[left];
              bestIndex = left;
              break;
            }
            if (right < TOTAL_FRAMES && images[right] && loadedMap[right]) {
              bestImg = images[right];
              bestIndex = right;
              break;
            }
          }
        }

        if (bestImg && bestIndex !== lastRenderedIndex) {
          drawImageToCanvas(bestImg);
          lastRenderedIndex = bestIndex;
        }
      }

      animId = requestAnimationFrame(render);
    }

    window.addEventListener('scroll', updateScrollProgress, { passive: true });
    window.addEventListener('resize', resizeCanvas, { passive: true });
    resizeCanvas();
    initSmartPreloader();
    updateScrollProgress();
    render();

    return () => {
      window.removeEventListener('scroll', updateScrollProgress);
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animId);
    };
  }, []);

  const handleCheckNowClick = () => {
    if (onCheckNow) {
      onCheckNow();
    } else if (onExploreExperience) {
      onExploreExperience();
    } else {
      const target = document.getElementById('amazing-destinations-section');
      if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <section id="hero-section" ref={trackRef} className="hero-scroll-track">
      <div className="hero-sticky-viewport">
        {/* 300-Frame Scroll Canvas */}
        <canvas id="heroCanvas" ref={canvasRef}></canvas>

        {/* Soft, Balanced Gradient Overlay for High Background Frame Visibility */}
        <div className="hero-content-overlay"></div>

        {/* Corner Watermark Concealer */}
        <div className="hero-watermark-cover"></div>

        {/* Hero Foreground Content */}
        <div className="hero-content-container">
          <div className="container-fluid px-4 px-md-5">
            <div className="row align-items-center g-5">
              
              {/* LEFT COLUMN: Frosted Glass Panel for 100% Crisp Legibility with Maximum Background Frame Visibility */}
              <div className="col-12 col-lg-7 col-xl-6 text-start">
                <div className="hero-glass-card">
                  {/* Main Headline: Matching Exact Reference Photo */}
                  <h1 id="hero-headline" className="hero-headline mb-4">
                    WE TURN YOUR IDEAS<br />
                    INTO MEMORABLE<br />
                    <span className="hero-highlight-gold">EXPERIENCES.</span>
                  </h1>

                  {/* Explore Now Button: Matching Exact Reference Photo */}
                  <div className="mb-4">
                    <button
                      id="hero-explore-now-btn"
                      type="button"
                      onClick={handleCheckNowClick}
                      className="btn-explore-hero"
                    >
                      <span>EXPLORE NOW</span>
                      <span className="btn-icon-bubble">
                        <i className="bi bi-arrow-right text-white"></i>
                      </span>
                    </button>
                  </div>

                  {/* 3 Feature Points Below Button: Matching Exact Reference Photo */}
                  <div className="hero-features-row">
                    <div className="hero-feature-item">
                      <span className="hero-feature-icon-circle">
                        <i className="bi bi-calendar3"></i>
                      </span>
                      <span className="hero-feature-text">Event Planning</span>
                    </div>
                    <div className="hero-feature-item">
                      <span className="hero-feature-icon-circle">
                        <i className="bi bi-airplane-fill"></i>
                      </span>
                      <span className="hero-feature-text">Travel Experiences</span>
                    </div>
                    <div className="hero-feature-item">
                      <span className="hero-feature-icon-circle">
                        <i className="bi bi-heart"></i>
                      </span>
                      <span className="hero-feature-text">Made Around You</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* RIGHT COLUMN: Clean empty space showing background animation */}
              <div className="col-12 col-lg-5 col-xl-6 d-none d-lg-block pointer-events-none">
                {/* Right column kept transparent for full background experience */}
              </div>

            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
