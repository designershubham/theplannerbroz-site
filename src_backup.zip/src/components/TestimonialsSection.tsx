import { useState } from 'react';
import { TESTIMONIALS } from '../data';

/* 
=========================================================================================
7. TESTIMONIALS SECTION COMPONENT
- Left: Headline & Prev / Next arrow buttons
- Right: Large quote card with avatar, rating stars, and testimonial quote
=========================================================================================
*/

export default function TestimonialsSection() {
  const [activeIndex, setActiveIndex] = useState(0);

  const prev = () => {
    setActiveIndex((current) => (current === 0 ? TESTIMONIALS.length - 1 : current - 1));
  };

  const next = () => {
    setActiveIndex((current) => (current === TESTIMONIALS.length - 1 ? 0 : current + 1));
  };

  const current = TESTIMONIALS[activeIndex] || TESTIMONIALS[0];

  return (
    <section id="testimonials-section" className="py-5 my-md-4 border-top">
      <div className="container-fluid px-4 px-md-5">
        <div className="row g-5 align-items-center">
          
          {/* Left Column: Heading & Controls */}
          <div className="col-12 col-lg-5">
            <span 
              id="testimonial-label"
              className="fw-bold small text-uppercase mb-3 d-block" 
              style={{ color: 'var(--brand-burgundy)' }}
            >
              <span className="badge rounded-circle p-1 me-1" style={{ background: 'var(--brand-gold)' }}> </span>
              Client Stories & Testimonials
            </span>
            
            <h2 id="testimonial-heading" className="h2 fw-normal lh-base text-dark mb-4">
              Here&apos;s what people have to say about working together. Real moments, real experiences, real feedback.
            </h2>

            {/* Prev / Next controls */}
            <div className="d-flex align-items-center gap-3 pt-2">
              <button
                id="testimonial-prev-btn"
                type="button"
                aria-label="Previous review"
                onClick={prev}
                className="btn btn-outline-custom rounded-circle p-2 px-3"
              >
                <i className="bi bi-chevron-left"></i>
              </button>
              <button
                id="testimonial-next-btn"
                type="button"
                aria-label="Next review"
                onClick={next}
                className="btn btn-gold rounded-circle p-2 px-3"
              >
                <i className="bi bi-chevron-right"></i>
              </button>
            </div>
          </div>

          {/* Right Column: Review Quote Card */}
          <div className="col-12 col-lg-7">
            <div 
              className="bg-white rounded-4 p-4 p-sm-5 border shadow-sm position-relative overflow-hidden"
              style={{ borderColor: 'rgba(0,0,0,0.08)' }}
            >
              {/* Gold Quote Icon */}
              <div className="mb-3 text-warning opacity-75 fs-1">
                <i className="bi bi-quote"></i>
              </div>

              <h3 id="testimonial-quote-headline" className="h4 fw-bold text-dark mb-3">
                {current.headline}
              </h3>

              <p id="testimonial-quote-text" className="text-muted leading-relaxed mb-4">
                &ldquo;{current.quote}&rdquo;
              </p>

              {/* Author & Rating */}
              <div className="d-flex align-items-center justify-content-between pt-3 border-top">
                <div className="d-flex align-items-center gap-3">
                  {current.avatar && (
                    <img 
                      src={current.avatar} 
                      alt={current.author}
                      className="rounded-circle object-fit-cover shadow-sm"
                      width="48"
                      height="48"
                      loading="lazy"
                    />
                  )}
                  <div>
                    <h5 className="mb-0 fw-bold text-dark fs-6">{current.author}</h5>
                    <small className="text-muted">{current.location || current.role}</small>
                  </div>
                </div>

                {/* Rating Stars */}
                <div className="text-warning">
                  {[...Array(5)].map((_, i) => (
                    <i key={i} className="bi bi-star-fill me-1"></i>
                  ))}
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
