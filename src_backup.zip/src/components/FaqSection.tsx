import { useState } from 'react';
import { FAQS, FAQ_PHOTO } from '../data';

/* 
=========================================================================================
8. FAQS SECTION COMPONENT (Accordion + Poolside Photo)
- Left Column: Interactive Accordion with collapsible answers
- Right Column: Luxury Sunset Pool Lounge Photo
=========================================================================================
*/

export default function FaqSection() {
  const [openId, setOpenId] = useState<string | null>('faq-1');

  const toggle = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  return (
    <section id="faqs-section" className="py-5 border-top">
      <div className="container-fluid px-4 px-md-5">
        <div className="row g-5 align-items-start">
          
          {/* Left Column: FAQs (Accordion) */}
          <div className="col-12 col-lg-7">
            <span 
              id="faq-label"
              className="fw-bold small text-uppercase mb-2 d-block" 
              style={{ color: 'var(--brand-burgundy)' }}
            >
              <span className="badge rounded-circle p-1 me-1" style={{ background: 'var(--brand-gold)' }}> </span>
              FAQs & Assistance
            </span>

            <h2 id="faq-title" className="h2 fw-bold text-dark mb-3">
              Got Questions?<br />We&apos;re Here to Help.
            </h2>

            <p id="faq-subtitle" className="text-muted small mb-4" style={{ maxWidth: '520px' }}>
              Find quick answers to common questions about booking, bespoke celebration coordination, payment options, and more.
            </p>

            {/* Accordion Container */}
            <div className="accordion border-top border-bottom" id="faqAccordion">
              {FAQS.map((faq) => {
                const isOpen = openId === faq.id;
                return (
                  <div key={faq.id} className="accordion-item border-0 border-bottom">
                    <h2 className="accordion-header">
                      <button
                        id={`faq-btn-${faq.id}`}
                        type="button"
                        onClick={() => toggle(faq.id)}
                        className={`accordion-button shadow-none fw-semibold ${isOpen ? '' : 'collapsed'}`}
                        style={{
                          backgroundColor: 'transparent',
                          color: isOpen ? 'var(--brand-burgundy)' : 'var(--brand-slate-900)'
                        }}
                      >
                        {faq.question}
                      </button>
                    </h2>
                    
                    {isOpen && (
                      <div id={`faq-answer-${faq.id}`} className="accordion-collapse collapse show animate-fade-in">
                        <div className="accordion-body text-muted small pt-1 pb-3">
                          {faq.answer}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

          </div>

          {/* Right Column: Poolside Sunset Photo */}
          <div className="col-12 col-lg-5">
            <div className="faq-image-card shiny-glass-effect rounded-4 overflow-hidden shadow-lg position-sticky" style={{ top: '100px', height: '500px' }}>
              <img 
                src={FAQ_PHOTO} 
                alt="Poolside Luxury Lounge" 
                className="w-100 h-100 object-fit-cover" 
                loading="lazy"
              />
              <div className="faq-image-badge">
                <i className="bi bi-stars"></i> Curated Stays &amp; Celebrations
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
