interface PlannerBrozLogoProps {
  className?: string;
  height?: number;
}

export default function PlannerBrozLogo({ className = '', height = 36 }: PlannerBrozLogoProps) {
  return (
    <div className={`d-flex align-items-center gap-2 user-select-none ${className}`} style={{ cursor: 'pointer' }}>
      <img
        src="/the-planner-broz-logo.svg"
        alt="The Planner Broz"
        height={height}
        style={{ height: `${height}px`, width: 'auto', objectFit: 'contain' }}
      />
      <span className="fw-bold d-none d-sm-inline-block text-dark" style={{ letterSpacing: '-0.02em', fontSize: '1.15rem' }}>
        The Planner Broz
      </span>
    </div>
  );
}
