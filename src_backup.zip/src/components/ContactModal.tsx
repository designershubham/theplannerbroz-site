import { useState, type FormEvent } from 'react';
import PlannerBrozLogo from './PlannerBrozLogo';

/* 
=========================================================================================
11. CONTACT CONCIERGE MODAL
- Direct transmission to info.tpbevent@gmail.com
- Full input validation (Name, Phone, Email, Service, Details)
- Bespoke luxury Thank You confirmation view
=========================================================================================
*/

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitSuccess?: (msg: string) => void;
}

export default function ContactModal({ isOpen, onClose, onSubmitSuccess }: ContactModalProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [service, setService] = useState('');
  const [message, setMessage] = useState('');

  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedRefId, setSubmittedRefId] = useState('');

  if (!isOpen) return null;

  const validate = () => {
    const errs: { [key: string]: string } = {};

    if (!name.trim() || name.trim().length < 2) {
      errs.name = 'Please enter your full name (minimum 2 letters).';
    }

    const digits = phone.replace(/\D/g, '');
    if (digits.length < 10 || digits.length > 15) {
      errs.phone = 'Please enter a valid 10-digit mobile number.';
    }

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!email.trim() || !emailRegex.test(email.trim())) {
      errs.email = 'Please enter a valid email address.';
    }

    if (!service.trim()) {
      errs.service = 'Please select what you want to plan.';
    }

    if (!message.trim() || message.trim().length < 5) {
      errs.message = 'Please provide details for your event or travel plan (min 5 characters).';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    const refId = 'TPB-' + Math.floor(100000 + Math.random() * 900000);
    setSubmittedRefId(refId);

    const emailPayload = {
      _subject: `✨ [NEW INQUIRY] ${service} — ${name.trim()} (${refId})`,
      _template: 'table',
      _captcha: 'false',
      _replyto: email.trim(),
      '👤 Client Full Name': name.trim(),
      '📞 Phone / WhatsApp': phone.trim(),
      '✉️ Email Address': email.trim(),
      '🎯 Selected Service': service,
      '📝 Event & Travel Details': message.trim(),
      '📅 Submission Date & Time': new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'full', timeStyle: 'medium' }),
      '🔖 Unique Reference ID': refId,
      '🌐 Source Platform': 'The Planner Broz React App'
    };

    try {
      await fetch('https://formsubmit.co/ajax/info.tpbevent@gmail.com', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(emailPayload)
      });
    } catch (err) {
      console.warn('FormSubmit notice:', err);
    }

    setIsSubmitting(false);
    setIsSubmitted(true);
    if (onSubmitSuccess) {
      onSubmitSuccess(`Thank you ${name}! Your inquiry has been sent to info.tpbevent@gmail.com.`);
    }
  };

  const handleClose = () => {
    setIsSubmitted(false);
    setName('');
    setPhone('');
    setEmail('');
    setMessage('');
    setErrors({});
    onClose();
  };

  const waMessage = encodeURIComponent(
    `Hello The Planner Broz! I just submitted an inquiry on your website.\n\n` +
    `• Name: ${name}\n` +
    `• Service: ${service}\n` +
    `• Ref ID: ${submittedRefId}\n` +
    `• Phone: ${phone}\n\n` +
    `Looking forward to planning with you!`
  );

  return (
    <div className="modal-backdrop-custom animate-fade-in" onClick={handleClose}>
      <div 
        className="modal-dialog-custom p-4"
        onClick={(e) => e.stopPropagation()}
        style={{ maxWidth: isSubmitted ? '520px' : '520px' }}
      >
        {isSubmitted ? (
          /* Bespoke Luxury Thank You Confirmation View */
          <div className="tpb-thankyou-content p-4 p-md-5 text-center">
            <button 
              type="button" 
              className="btn-close btn-close-white tpb-thankyou-close-btn" 
              aria-label="Close"
              onClick={handleClose}
            ></button>

            <div className="tpb-thankyou-icon-wrapper mb-3">
              <div className="tpb-thankyou-icon-aura"></div>
              <div className="tpb-thankyou-icon-circle">
                <i className="bi bi-check-lg"></i>
              </div>
              <div className="tpb-thankyou-sparkle-1">✦</div>
              <div className="tpb-thankyou-sparkle-2">✦</div>
            </div>

            <div className="mb-2">
              <span className="tpb-thankyou-badge">
                <i className="bi bi-stars"></i> INQUIRY TRANSMITTED
              </span>
            </div>

            <h3 className="tpb-thankyou-title mb-1">
              Thank You, <span style={{ color: '#F4D06F' }}>{name}</span>!
            </h3>

            <div className="tpb-hero-script tpb-thankyou-script mb-3">
              We Plan, You Celebrate
            </div>

            <p className="tpb-thankyou-desc mb-4">
              Aapki inquiry hamare lead concierge team ko <strong>info.tpbevent@gmail.com</strong> par safely receive ho chuki hai. Our senior planning team will connect with you within <strong>2 to 4 hours</strong>.
            </p>

            <div className="tpb-thankyou-summary-card mb-4 text-start">
              <div className="row g-2">
                <div className="col-6">
                  <span className="tpb-summary-label">Reference ID</span>
                  <span className="tpb-summary-value text-warning">{submittedRefId}</span>
                </div>
                <div className="col-6">
                  <span className="tpb-summary-label">Status</span>
                  <span className="tpb-summary-value text-success">
                    <i className="bi bi-check-circle-fill me-1"></i> Priority Queue
                  </span>
                </div>
                <div className="col-12 mt-2 pt-2 border-top border-white border-opacity-10">
                  <span className="tpb-summary-label">Selected Experience</span>
                  <span className="tpb-summary-value">{service}</span>
                </div>
                <div className="col-6 mt-2 pt-2 border-top border-white border-opacity-10">
                  <span className="tpb-summary-label">Client Contact</span>
                  <span className="tpb-summary-value">{phone}</span>
                </div>
                <div className="col-6 mt-2 pt-2 border-top border-white border-opacity-10">
                  <span className="tpb-summary-label">Delivered To</span>
                  <span className="tpb-summary-value" style={{ color: '#F4D06F', fontSize: '12px' }}>info.tpbevent@gmail.com</span>
                </div>
              </div>
            </div>

            <div className="d-flex flex-column flex-sm-row gap-2">
              <a 
                href={`https://wa.me/919718470384?text=${waMessage}`}
                target="_blank" 
                rel="noreferrer"
                className="btn tpb-btn-whatsapp flex-fill"
              >
                <i className="bi bi-whatsapp me-2"></i> Chat on WhatsApp
              </a>
              <button 
                type="button" 
                className="btn tpb-btn-dismiss flex-fill"
                onClick={handleClose}
              >
                Explore Website
              </button>
            </div>
          </div>
        ) : (
          /* Input Form */
          <>
            <div className="d-flex justify-content-between align-items-start mb-3">
              <div>
                <span 
                  className="badge rounded-pill px-3 py-1 mb-2" 
                  style={{ 
                    background: 'rgba(61,17,26,0.08)', 
                    color: 'var(--brand-burgundy)', 
                    border: '1px solid rgba(197,155,63,0.3)', 
                    fontSize: '11px' 
                  }}
                >
                  <i className="bi bi-stars me-1" style={{ color: 'var(--brand-gold)' }}></i>
                  WE PLAN, YOU CELEBRATE
                </span>
                <div className="mb-2">
                  <PlannerBrozLogo height={32} />
                </div>
                <h4 className="fw-bold text-dark mb-1">Contact Concierge</h4>
                <p className="text-muted small mb-0">Direct luxury concierge for bespoke events & bookings.</p>
              </div>
              
              <button 
                type="button" 
                className="btn-close" 
                aria-label="Close"
                onClick={handleClose}
              ></button>
            </div>

            {/* Quick Contact Buttons */}
            <div className="d-flex gap-2 mb-3">
              <a 
                href="tel:+919718470384" 
                className="btn btn-sm btn-light border flex-fill text-dark fw-semibold py-2 d-flex align-items-center justify-content-center gap-1"
              >
                <i className="bi bi-telephone-fill" style={{ color: 'var(--brand-gold)' }}></i>
                <span>+91 97184 70384</span>
              </a>
              <a 
                href="mailto:info.tpbevent@gmail.com" 
                className="btn btn-sm btn-light border flex-fill text-dark fw-semibold py-2 d-flex align-items-center justify-content-center gap-1"
              >
                <i className="bi bi-envelope-fill" style={{ color: 'var(--brand-gold)' }}></i>
                <span>Email Concierge</span>
              </a>
            </div>

            <form onSubmit={handleSubmit} className="tpb-contact-form" noValidate>
              <div className="mb-3">
                <label className="form-label small fw-semibold text-muted">
                  Your Full Name <span className="text-danger">*</span>
                </label>
                <input 
                  type="text" 
                  className={`form-control rounded-3 ${errors.name ? 'is-invalid' : ''}`}
                  placeholder="e.g. Rahul Sharma" 
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (errors.name) setErrors(prev => ({ ...prev, name: '' }));
                  }}
                  required 
                />
                {errors.name && <div className="invalid-feedback d-block">{errors.name}</div>}
              </div>

              <div className="row g-2 mb-3">
                <div className="col-6">
                  <label className="form-label small fw-semibold text-muted">
                    Phone / WhatsApp <span className="text-danger">*</span>
                  </label>
                  <input 
                    type="tel" 
                    className={`form-control rounded-3 ${errors.phone ? 'is-invalid' : ''}`}
                    placeholder="+91 97184 70384" 
                    value={phone}
                    onChange={(e) => {
                      setPhone(e.target.value);
                      if (errors.phone) setErrors(prev => ({ ...prev, phone: '' }));
                    }}
                    required 
                  />
                  {errors.phone && <div className="invalid-feedback d-block">{errors.phone}</div>}
                </div>
                <div className="col-6">
                  <label className="form-label small fw-semibold text-muted">
                    Email Address <span className="text-danger">*</span>
                  </label>
                  <input 
                    type="email" 
                    className={`form-control rounded-3 ${errors.email ? 'is-invalid' : ''}`}
                    placeholder="rahul@example.com" 
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (errors.email) setErrors(prev => ({ ...prev, email: '' }));
                    }}
                    required 
                  />
                  {errors.email && <div className="invalid-feedback d-block">{errors.email}</div>}
                </div>
              </div>

              <div className="mb-3">
                <label className="form-label small fw-semibold text-muted">Service Type</label>
                <select 
                  className={`form-select rounded-3 ${errors.service ? 'is-invalid' : ''}`}
                  value={service}
                  onChange={(e) => {
                    setService(e.target.value);
                    if (errors.service) setErrors(prev => ({ ...prev, service: '' }));
                  }}
                  required
                >
                  <option value="" disabled>What you want to plan</option>
                  <option value="Event planning">Event planning</option>
                  <option value="Travel planning">Travel planning</option>
                  <option value="Customized your plan">Customized your plan</option>
                </select>
                {errors.service && <div className="invalid-feedback d-block">{errors.service}</div>}
              </div>

              <div className="mb-3">
                <label className="form-label small fw-semibold text-muted">
                  Occasion or Destination Details <span className="text-danger">*</span>
                </label>
                <textarea 
                  className={`form-control rounded-3 ${errors.message ? 'is-invalid' : ''}`}
                  rows={3} 
                  placeholder="Share event dates, expected guest count, or destination preferences..."
                  value={message}
                  onChange={(e) => {
                    setMessage(e.target.value);
                    if (errors.message) setErrors(prev => ({ ...prev, message: '' }));
                  }}
                  required
                ></textarea>
                {errors.message && <div className="invalid-feedback d-block">{errors.message}</div>}
              </div>

              <button 
                type="submit" 
                className="btn btn-gold w-100 py-2 fw-semibold"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    Transmitting to Concierge...
                  </>
                ) : (
                  <>
                    <i className="bi bi-send me-1"></i> Submit Contact Request
                  </>
                )}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}

