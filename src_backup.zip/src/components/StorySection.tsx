/* 
=========================================================================================
3. OUR STORY SECTION COMPONENT (Matching Reference Photo Exact Design)
- Authentic co-founders visual showcase with organic pebble frame & gold border
- Floating badges: Mountains (Travel) & Clinking Glasses (Events) with sparkle rays
- Floating handwritten note: "We Plan, You Celebrate ♡"
- Left column: "OUR STORY" kicker, Serif headline with gold flourish underline
- Highlighted narrative paragraphs & "Our Vision" block with bullseye target icon
- Corner doodle line art decorations
=========================================================================================
*/

export default function StorySection() {
  return (
    <section id="ourStorySection" className="our-story-section">
      {/* Corner Background Doodles (Matching Reference Photo) */}
      {/* Bottom-Left: Mountains, Sun, Palm Tree, Pathway */}
      <svg className="story-doodle-bl" viewBox="0 0 220 180" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <circle cx="100" cy="50" r="10" stroke="#D1B892" strokeWidth="1.3" strokeDasharray="2 2" />
        <path d="M100 32v6M100 62v6M82 50h6M112 50h6M87 37l4 4M109 59l4 4M87 63l4-4M109 41l4-4" stroke="#D1B892" strokeWidth="1.3" />
        <path d="M40 140L80 75L120 140" stroke="#D1B892" strokeWidth="1.5" strokeLinejoin="round" />
        <path d="M80 75L72 90M80 75L88 92" stroke="#D1B892" strokeWidth="1.2" />
        <path d="M95 140L135 85L175 140" stroke="#D1B892" strokeWidth="1.5" strokeLinejoin="round" />
        <path d="M135 85L128 98M135 85L142 100" stroke="#D1B892" strokeWidth="1.2" />
        <path d="M10 160L50 110L90 160" stroke="#D1B892" strokeWidth="1.4" strokeLinejoin="round" />
        <path d="M30 165Q26 125 35 100" stroke="#D1B892" strokeWidth="1.5" strokeLinecap="round" />
        <path d="M35 100Q20 90 10 95M35 100Q25 80 18 82M35 100Q42 75 52 80M35 100Q50 90 58 100M35 100Q36 85 45 88" stroke="#D1B892" strokeWidth="1.3" strokeLinecap="round" />
        <path d="M20 178Q60 168 80 155T150 145" stroke="#D1B892" strokeWidth="1.3" strokeDasharray="3 3" />
        <path d="M35 180Q75 172 95 160T165 148" stroke="#D1B892" strokeWidth="1.3" strokeDasharray="3 3" />
      </svg>

      {/* Top-Right: Dotted Flight Path & Airplane */}
      <svg className="story-doodle-tr" viewBox="0 0 160 130" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <path d="M10 110Q60 30 130 20" stroke="#D1B892" strokeWidth="1.4" strokeDasharray="4 4" />
        <g transform="translate(122, 10) rotate(42)">
          <path d="M12 2L15 9L22 11L16 16L18 23L12 19L6 23L8 16L2 11L9 9L12 2Z" fill="#B88628" stroke="#B88628" strokeWidth="0.5" />
        </g>
      </svg>

      {/* Bottom-Right: Celebration Dining Setup */}
      <svg className="story-doodle-br" viewBox="0 0 240 180" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <path d="M50 40Q120 15 190 40" stroke="#D1B892" strokeWidth="1.4" />
        <path d="M50 40Q85 60 120 45Q155 60 190 40" stroke="#D1B892" strokeWidth="1.2" />
        <path d="M50 40v120M190 40v120" stroke="#D1B892" strokeWidth="1.4" />
        <path d="M50 40Q35 80 40 140M190 40Q205 80 200 140" stroke="#D1B892" strokeWidth="1.2" />
        <path d="M75 115h90v45H75z" stroke="#D1B892" strokeWidth="1.3" />
        <path d="M70 115h100" stroke="#D1B892" strokeWidth="1.5" />
        <path d="M72 115Q85 135 120 130Q155 135 168 115" stroke="#D1B892" strokeWidth="1.2" />
        <path d="M55 100h12v60H55zM173 100h12v60h-12z" stroke="#D1B892" strokeWidth="1.2" />
        <path d="M58 85h6v15h-6zM176 85h6v15h-6z" stroke="#D1B892" strokeWidth="1.2" />
        <path d="M25 145h15l-3 18h-9z" stroke="#D1B892" strokeWidth="1.2" />
        <path d="M32 145Q22 130 18 135M32 145Q32 125 30 128M32 145Q42 130 46 134" stroke="#D1B892" strokeWidth="1.2" />
        <path d="M10 165Q60 155 110 168T220 160" stroke="#D1B892" strokeWidth="1.2" strokeDasharray="3 3" />
      </svg>

      <div className="container px-4 px-lg-5 position-relative" style={{ zIndex: 3, maxWidth: 1240 }}>
        <div className="row g-4 g-lg-5 align-items-center">

          {/* LEFT COLUMN: Story Content */}
          <div className="col-12 col-lg-6 col-xl-6 text-start">
            {/* Kicker / Subtitle */}
            <div className="d-flex align-items-center gap-2 mb-3">
              <span className="story-kicker-dot"></span>
              <span className="story-kicker-text">OUR STORY</span>
              <span className="story-kicker-line"></span>
            </div>

            {/* Headline: Matching Exact Photo */}
            <h2 className="story-heading">
              <span className="story-heading-line1">From Ideas to</span>
              <span className="story-heading-line2">
                <span className="story-burgundy">Unforgettable</span>{' '}
                <span className="story-gold">
                  Experiences
                  {/* Golden Curved Flourish Underline */}
                  <svg className="story-gold-flourish" viewBox="0 0 180 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 12C50 2 130 2 178 11" stroke="#B88628" strokeWidth="2.5" strokeLinecap="round" />
                  </svg>
                </span>
              </span>
            </h2>

            {/* Paragraph 1 */}
            <p className="our-story-p mb-3">
              The Planner Broz started with a simple thought — planning should feel <strong className="story-highlight-burgundy">exciting, not stressful.</strong> We bring together event planning and travel experiences to turn your ideas into well-organised, memorable moments.
            </p>

            {/* Paragraph 2 */}
            <p className="our-story-p mb-4">
              From celebrations and corporate events to group trips and special journeys, we focus on understanding what you want, planning every detail carefully, and creating experiences you'll be happy to remember.
            </p>

            {/* "Our Vision" Feature Block */}
            <div className="story-vision-wrap">
              {/* Target / Bullseye with arrow icon */}
              <div className="story-vision-icon-circle">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <circle cx="12" cy="12" r="6"></circle>
                  <circle cx="12" cy="12" r="2"></circle>
                  <path d="m14 10 7-7"></path>
                  <path d="M21 3h-5"></path>
                  <path d="M21 3v5"></path>
                </svg>
              </div>

              {/* Vertical Divider Line */}
              <div className="story-vision-divider"></div>

              {/* Vision Content */}
              <div className="story-vision-content">
                <h4 className="story-vision-title">Our Vision</h4>
                <p className="story-vision-desc mb-0">
                  To create thoughtful events and journeys where every detail matters and every moment feels worth remembering.
                </p>
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: Visual Frame & Floating Badges */}
          <div className="col-12 col-lg-6 col-xl-6">
            <div className="story-visual-container">

              {/* Deep Burgundy Offset Background Shape */}
              <div className="story-image-backdrop"></div>

              {/* Organic Pebble Curved Image Card with Gold Border */}
              <div className="story-image-card">
                <img src="/assets/our-story-founders.jpg" alt="The Planner Broz Co-founders collaborating" />
              </div>

              {/* Floating Badge 1: Mountains (Left) with Sparkle Rays */}
              <div className="story-sparkle-mountain">
                <svg width="20" height="14" viewBox="0 0 20 14" fill="none" stroke="#B88628" strokeWidth="1.5" strokeLinecap="round">
                  <path d="M10 1v4M3 8l3-2M17 8l-3-2" />
                </svg>
              </div>
              <div className="story-badge-mountain" title="Travel Experiences">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m8 3 4 8 5-5 5 11H2L8 3z"></path>
                  <path d="M6.5 13.5 8 11l2 2.5"></path>
                  <path d="m15 10 2 2.5 2-1.5"></path>
                </svg>
              </div>

              {/* Floating Badge 2: Clinking Glasses (Bottom-Right) with Sparkle Rays */}
              <div className="story-sparkle-cheers">
                <svg width="20" height="14" viewBox="0 0 20 14" fill="none" stroke="#B88628" strokeWidth="1.5" strokeLinecap="round">
                  <path d="M10 1v4M3 8l3-2M17 8l-3-2" />
                </svg>
              </div>
              <div className="story-badge-cheers" title="Celebrations & Events">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M7 3l3 8a3 3 0 0 1-2.5 3.8L7 15v5m-3 0h6"></path>
                  <path d="M17 3l-3 8a3 3 0 0 0 2.5 3.8L17 15v5m-3 0h6"></path>
                  <circle cx="12" cy="5" r="1" fill="#ffffff"></circle>
                  <circle cx="10" cy="2" r="0.75" fill="#ffffff"></circle>
                  <circle cx="14" cy="2" r="0.75" fill="#ffffff"></circle>
                </svg>
              </div>

              {/* Floating Handwritten Sticker Note: "We Plan, You Celebrate ♡" */}
              <div className="story-sticker-note">
                <span className="story-sticker-line1">We Plan,</span>
                <span className="story-sticker-line2">You Celebrate <span className="story-sticker-heart">♡</span></span>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
