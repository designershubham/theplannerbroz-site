import React from 'react';
import { ServiceCategory } from '../data/servicesData';

interface ServiceCategoriesProps {
  categories: ServiceCategory[];
}

export const ServiceCategories: React.FC<ServiceCategoriesProps> = ({ categories }) => {
  return (
    <div className="tpb-category-bar-wrapper">
      <div className="tpb-category-bar">
        {categories.map((cat) => (
          <div key={cat.id} className="tpb-category-item" data-cat-id={cat.id}>
            <i className={`bi ${cat.icon} tpb-category-icon`}></i>
            <span className="tpb-category-name">{cat.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ServiceCategories;
