import { useState, useEffect } from 'react';
import PlannerBrozLogo from './PlannerBrozLogo';

/* 
=========================================================================================
1. NAVBAR COMPONENT (Sticky Glassmorphic Navigation)
- Yahan se aap Nav Links aur Buttons badal sakte hain.
=========================================================================================
*/

interface NavbarProps {
  activeTab?: string;
  onSelectTab?: (tab: string) => void;
  onContactNow?: () => void;
}

export default function Navbar({
  activeTab = 'Event Plans',
  onSelectTab,
  onContactNow,
}: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 25);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = ['Event Plans', 'Travel Plans', 'Reviews'];

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="navbar-floating-container px-3 px-md-4">
      {/* Centered Floating Glassmorphic Pill */}
      <nav
        id="main-navbar"
        aria-label="Main Navigation"
        className={`navbar-pill ${isScrolled ? 'scrolled' : ''}`}
      >
        {/* Left Side: Brand Logo */}
        <div 
          id="navbar-brand-logo" 
          onClick={scrollToTop}
          title="The Planner Broz"
        >
          <PlannerBrozLogo height={34} />
        </div>

        {/* Center: Navigation Links */}
        <div className="d-none d-md-flex align-items-center gap-1 bg-white border border-light-subtle rounded-pill p-1 shadow-sm">
          {menuItems.map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => onSelectTab?.(item)}
              className={`nav-link-btn ${activeTab === item ? 'active' : ''}`}
            >
              {item}
            </button>
          ))}
        </div>

        {/* Right Side: Contact Now Button */}
        <div className="d-flex align-items-center gap-2">
          <button
            type="button"
            onClick={onContactNow}
            className="btn-navbar-contact"
            id="navbar-contact-btn"
          >
            <span>Contact Now</span>
          </button>
        </div>
      </nav>
    </header>
  );
}
