import React from 'react';
import { ServiceSectionConfig } from '../data/servicesData';
import ServiceCategories from './ServiceCategories';

interface ServiceHeroProps {
  config: ServiceSectionConfig;
}

export const ServiceHero: React.FC<ServiceHeroProps> = ({ config }) => {
  const {
    badgeIcon,
    badgeText,
    headingMain,
    headingSub,
    headingHighlight,
    description,
    ctaText,
    ctaLink,
    heroBackgroundImage,
    categories,
  } = config;

  return (
    <div className="tpb-hero-card-wrapper">
      <div
        className="tpb-hero-card"
        style={{ backgroundImage: `url(${heroBackgroundImage})` }}
      >
        <div className="tpb-hero-overlay"></div>
        <div className="tpb-hero-bottom-shade"></div>

      <div className="tpb-hero-inner">
        <div className="tpb-hero-left-col">
          <div className="tpb-badge-pill">
            <span className="tpb-badge-icon">{badgeIcon}</span>
            <span>{badgeText}</span>
          </div>

          <h2 className="tpb-hero-title">
            {headingMain}
            <br />
            <span>{headingSub}</span>
            <span className="tpb-hero-script">{headingHighlight}</span>
          </h2>

          <p className="tpb-hero-desc">{description}</p>

          <a href={ctaLink} className="tpb-hero-btn">
            <span>{ctaText}</span>
            <i className="bi bi-arrow-right"></i>
          </a>
        </div>

        <ServiceCategories categories={categories} />
      </div>
    </div>
  </div>
  );
};

export default ServiceHero;
