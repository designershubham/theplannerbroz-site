import { TestimonialItem, FaqItem } from './types';

/* 
=========================================================================================
WEBSITE DATA CONFIGURATION (Yahan se data badlein)
Aap kisi bhi text, image URL, ya price ko yahan asani se edit kar sakte hain:
=========================================================================================
*/

// 1. HERO SECTION DATA
export const HERO_DATA = {
  brandName: 'The Planner Broz',
  tagline: 'The Planner Broz • We Plan, You Celebrate',
  headline: 'WE TURN YOUR IDEAS INTO MEMORABLE EXPERIENCES.',
  checkNowButtonText: 'EXPLORE NOW',
  features: [
    { label: 'Event Planning', icon: 'bi-calendar3' },
    { label: 'Travel Experiences', icon: 'bi-airplane-fill' },
    { label: 'Made Around You', icon: 'bi-heart' },
  ],
  bgImage: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=2000&auto=format&fit=crop'
};

// 2. OUR STORY DATA
export const STORY_DATA = {
  badge: 'Our Story',
  highlightText: 'Trusted by over 10 million travelers worldwide, we\'re proud to deliver top-rated stays with an average rating of 4.8★. Your celebrations, comfort, and memories are our utmost priority.',
  mainStatement: 'From city escapes to beachside retreats and celebratory galas, we connect you with places and moments that fit your lifestyle wherever the journey takes you.',
  buttonText: 'Learn More'
};

// 3. CLIENT TESTIMONIALS
export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 't-1',
    author: 'Aarav & Meera Kapoor',
    location: 'Destination Wedding, Udaipur',
    role: 'Couple & Hosts',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    headline: '“The Planner Broz made our destination wedding completely magical and stress-free.”',
    quote: 'From villa bookings across Lake Pichola to chartered logistics and royal decor, the team handled every detail with effortless perfection. Our 300 guests are still talking about it.',
    rating: 5
  },
  {
    id: 't-2',
    author: 'Julian & Sophia Vance',
    location: 'Private Retreat, Amalfi Coast',
    role: 'Family Vacation',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    headline: '“Unmatched concierge hospitality from initial booking to departure.”',
    quote: 'We booked a private cliff sanctuary through The Planner Broz. Every expectation was exceeded: private boat charters, Michelin-star dining, and 24/7 personal care.',
    rating: 5
  }
];

// 7. FREQUENTLY ASKED QUESTIONS (Accordion)
export const FAQS: FaqItem[] = [
  {
    id: 'faq-1',
    question: '1. How do I book an event or trip with The Planner Broz?',
    answer: 'Simply contact us and share your event or travel plan, date, location and requirements. We’ll discuss the details with you and create a plan that fits your needs and budget.'
  },
  {
    id: 'faq-2',
    question: '2. How much does an event or trip cost?',
    answer: 'There is no fixed price because every requirement is different. We first understand what you need, then share a clear quotation based on your selected services.'
  },
  {
    id: 'faq-3',
    question: '3. Can I customise the event or trip according to my budget?',
    answer: 'Yes. We can adjust the plan, services and arrangements according to your budget while keeping the experience comfortable and well planned.'
  },
  {
    id: 'faq-4',
    question: '4. Do you handle everything on the event/trip day?',
    answer: 'Yes. Once the plan is finalised, our team coordinates the agreed arrangements so you can focus on enjoying the event or journey.'
  },
  {
    id: 'faq-5',
    question: '5. What happens if my plans change after booking?',
    answer: 'Just let us know as early as possible. We’ll check what changes can be made based on the bookings already confirmed and the applicable cancellation or change terms.'
  },
  {
    id: 'faq-6',
    question: '6. Can you arrange transport, hotels and other bookings for trips?',
    answer: 'Yes. Depending on your package, we can help arrange transportation, stays, meals, sightseeing and other agreed travel requirements.'
  }
];

// FAQ Side Photo (Luxury Poolside Sunset Lounge)
export const FAQ_PHOTO = 'https://images.unsplash.com/photo-1540541338287-41700207dee6?q=80&w=1000&auto=format&fit=crop';

// 8. CONTACT & FOOTER INFO
export const CONTACT_INFO = {
  brandName: 'The Planner Broz',
  tagline: 'We Plan, You Celebrate',
  description: 'Global Luxury Concierge & Destination Planning for bespoke events, private villas, and memorable stays.',
  email: 'info@theplannerbroz.com',
  phone: '+1 (800) 752-6637',
  whatsapp: '+91 98765 43210',
  socials: ['Facebook', 'Instagram', 'YouTube', 'Twitter', 'LinkedIn'],
  legal: ['Privacy Policy', 'Terms of Use', 'Legal Disclaimer', 'Cookie Policy']
};
